import React, { useMemo, useState } from 'react';
import { useCompany } from '../../store/CompanyContext';
import { Department, Timeframe } from '../../types';

interface TeamWorkloadDonutProps {
  timeframe: Timeframe;
  onSelectDepartment?: (dept: Department) => void;
}

const DEPT_COLORS: Record<Department, string> = {
  Engineering: '#00D26A',
  Design: '#D9A05B',
  Marketing: '#38BDF8',
  'Quality Assurance': '#FBBF24',
  Product: '#34D399',
  Operations: '#94A3B8',
};

export const TeamWorkloadDonut: React.FC<TeamWorkloadDonutProps> = ({
  timeframe,
  onSelectDepartment,
}) => {
  const { employees } = useCompany();
  const [hoveredDept, setHoveredDept] = useState<Department | null>(null);

  const multiplier = timeframe === 'week' ? 1 : timeframe === 'month' ? 0.96 : 1.04;

  const { segments, totalCapacityPct } = useMemo(() => {
    const deptTotals = new Map<Department, number>();
    let totalAllocated = 0;
    let totalCapacity = 0;

    employees.forEach((emp) => {
      const alloc = Math.round(emp.allocatedHours * multiplier);
      totalAllocated += alloc;
      totalCapacity += emp.weeklyCapacityHours;
      deptTotals.set(emp.department, (deptTotals.get(emp.department) ?? 0) + alloc);
    });

    const pct = totalCapacity > 0 ? Math.min(100, Math.round((totalAllocated / totalCapacity) * 100)) : 0;

    const list = Array.from(deptTotals.entries())
      .map(([department, hours]) => ({
        department,
        hours,
        sharePct: totalAllocated > 0 ? Math.round((hours / totalAllocated) * 100) : 0,
        color: DEPT_COLORS[department],
      }))
      .sort((a, b) => b.hours - a.hours);

    return { segments: list, totalCapacityPct: pct };
  }, [employees, multiplier]);

  const radius = 58;
  const circumference = 2 * Math.PI * radius;
  let cumulative = 0;

  const activeSegment = segments.find((s) => s.department === hoveredDept);

  return (
    <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-5 flex flex-col justify-between">
      <div className="flex items-center justify-between gap-2 mb-4">
        <div>
          <h2 className="font-display text-[16px] font-bold text-[#F3F5F7]">Team Workload</h2>
          <p className="text-xs text-[#9CA3AF] mt-0.5">Allocation by department capacity</p>
        </div>
        <span className="text-xs font-medium text-[#D1D5DB] bg-[#1A1E24] border border-[#262C36] rounded-lg px-2.5 py-1 capitalize">
          {timeframe === 'week' ? 'This Week' : timeframe === 'month' ? 'This Month' : 'This Quarter'}
        </span>
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-6 my-auto">
        <div className="relative w-40 h-40 shrink-0 flex items-center justify-center">
          <svg viewBox="0 0 156 156" className="w-full h-full -rotate-90">
            <circle
              cx="78"
              cy="78"
              r={radius}
              fill="none"
              stroke="#1F242C"
              strokeWidth="18"
            />
            {segments.map((seg) => {
              const dashLength = (seg.sharePct / 100) * circumference;
              const dashOffset = -cumulative;
              cumulative += dashLength;
              const isHovered = hoveredDept === seg.department;
              return (
                <circle
                  key={seg.department}
                  cx="78"
                  cy="78"
                  r={radius}
                  fill="none"
                  stroke={seg.color}
                  strokeWidth={isHovered ? 22 : 18}
                  strokeDasharray={`${Math.max(0, dashLength - 2.5)} ${circumference}`}
                  strokeDashoffset={dashOffset}
                  strokeLinecap="butt"
                  className="cursor-pointer transition-all duration-150"
                  onMouseEnter={() => setHoveredDept(seg.department)}
                  onMouseLeave={() => setHoveredDept(null)}
                  onClick={() => onSelectDepartment?.(seg.department)}
                />
              );
            })}
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none px-4">
            <span className="font-display text-2xl font-bold text-[#F3F5F7] tabular-nums leading-none">
              {activeSegment ? `${activeSegment.sharePct}%` : `${totalCapacityPct}%`}
            </span>
            <span className="text-[11px] text-[#9CA3AF] mt-1 leading-tight">
              {activeSegment ? activeSegment.department : 'Total Capacity'}
            </span>
          </div>
        </div>

        <div className="flex-1 w-full space-y-2.5">
          {segments.map((seg) => {
            const isHovered = hoveredDept === seg.department;
            return (
              <button
                key={seg.department}
                type="button"
                onMouseEnter={() => setHoveredDept(seg.department)}
                onMouseLeave={() => setHoveredDept(null)}
                onClick={() => onSelectDepartment?.(seg.department)}
                className={`w-full flex items-center justify-between text-xs px-2 py-1 rounded-lg transition-colors ${
                  isHovered ? 'bg-[#1B2028]' : ''
                }`}
              >
                <span className="flex items-center gap-2.5 text-[#D1D5DB] font-medium truncate">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: seg.color }}
                  />
                  <span className="truncate">{seg.department}</span>
                </span>
                <span className="font-mono font-semibold text-[#F3F5F7] tabular-nums shrink-0">
                  {seg.sharePct}%
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
