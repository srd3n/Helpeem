import React, { useMemo, useState } from 'react';
import { ANALYTICS_SERIES } from '../../data/initialData';
import { Timeframe } from '../../types';

interface WorkflowAnalyticsChartProps {
  timeframe: Timeframe;
}

function buildSmoothPath(points: { x: number; y: number }[]): string {
  if (points.length === 0) return '';
  if (points.length === 1) return `M ${points[0].x} ${points[0].y}`;
  let d = `M ${points[0].x} ${points[0].y}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i];
    const p1 = points[i + 1];
    const cx = (p0.x + p1.x) / 2;
    d += ` C ${cx} ${p0.y}, ${cx} ${p1.y}, ${p1.x} ${p1.y}`;
  }
  return d;
}

export const WorkflowAnalyticsChart: React.FC<WorkflowAnalyticsChartProps> = ({ timeframe }) => {
  const data = ANALYTICS_SERIES[timeframe];
  const [hoveredIdx, setHoveredIdx] = useState<number>(Math.min(3, data.length - 1));

  const chart = useMemo(() => {
    const width = 620;
    const height = 220;
    const padLeft = 38;
    const padRight = 18;
    const padTop = 18;
    const padBottom = 32;
    const plotW = width - padLeft - padRight;
    const plotH = height - padTop - padBottom;

    const maxRaw = Math.max(...data.flatMap((d) => [d.completed, d.created]), 10);
    const yMax = Math.ceil(maxRaw / 25) * 25;

    const mapPoint = (idx: number, val: number) => ({
      x: padLeft + (idx / Math.max(1, data.length - 1)) * plotW,
      y: padTop + plotH - (val / yMax) * plotH,
    });

    const completedPts = data.map((d, i) => mapPoint(i, d.completed));
    const createdPts = data.map((d, i) => mapPoint(i, d.created));

    const completedLine = buildSmoothPath(completedPts);
    const createdLine = buildSmoothPath(createdPts);

    const baselineY = padTop + plotH;
    const completedArea = `${completedLine} L ${completedPts[completedPts.length - 1].x} ${baselineY} L ${completedPts[0].x} ${baselineY} Z`;
    const createdArea = `${createdLine} L ${createdPts[createdPts.length - 1].x} ${baselineY} L ${createdPts[0].x} ${baselineY} Z`;

    const ticks = [0, 0.25, 0.5, 0.75, 1].map((t) => ({
      value: Math.round(t * yMax),
      y: padTop + plotH - t * plotH,
    }));

    return {
      width,
      height,
      padTop,
      baselineY,
      completedPts,
      createdPts,
      completedLine,
      createdLine,
      completedArea,
      createdArea,
      ticks,
    };
  }, [data]);

  const activeIdx = Math.min(hoveredIdx, data.length - 1);
  const activeDatum = data[activeIdx];
  const activeCompPt = chart.completedPts[activeIdx];

  const subtitleMap: Record<Timeframe, string> = {
    week: 'Task progress over the last 6 weeks',
    month: 'Monthly task throughput across departments',
    quarter: 'Quarterly task velocity comparison',
  };

  return (
    <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-5 flex flex-col justify-between">
      <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
        <div>
          <h2 className="font-display text-[16px] font-bold text-[#F3F5F7]">Workflow Analytics</h2>
          <p className="text-xs text-[#9CA3AF] mt-0.5">{subtitleMap[timeframe]}</p>
        </div>

        <div className="flex items-center gap-4 text-xs font-medium text-[#D1D5DB]">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#00D26A]" />
            Completed
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#D9A05B]" />
            Created
          </span>
        </div>
      </div>

      <div className="relative w-full">
        <svg
          viewBox={`0 0 ${chart.width} ${chart.height}`}
          className="w-full h-auto overflow-visible"
          role="img"
          aria-label="Workflow Analytics completed vs created tasks chart"
        >
          <defs>
            <linearGradient id="wf-grad-completed" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#00D26A" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#00D26A" stopOpacity="0.0" />
            </linearGradient>
            <linearGradient id="wf-grad-created" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#D9A05B" stopOpacity="0.16" />
              <stop offset="100%" stopColor="#D9A05B" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Horizontal Grid Lines & Y-Axis Ticks */}
          {chart.ticks.map((tick) => (
            <g key={tick.value}>
              <line
                x1={34}
                y1={tick.y}
                x2={chart.width - 14}
                y2={tick.y}
                stroke="#1F242C"
                strokeWidth="1"
              />
              <text
                x={26}
                y={tick.y + 4}
                textAnchor="end"
                className="fill-[#6B7280] text-[11px] font-mono tabular-nums"
              >
                {tick.value}
              </text>
            </g>
          ))}

          {/* Area Fills */}
          <path d={chart.createdArea} fill="url(#wf-grad-created)" />
          <path d={chart.completedArea} fill="url(#wf-grad-completed)" />

          {/* Smooth Lines */}
          <path
            d={chart.createdLine}
            fill="none"
            stroke="#D9A05B"
            strokeWidth="2.4"
            strokeLinecap="round"
          />
          <path
            d={chart.completedLine}
            fill="none"
            stroke="#00D26A"
            strokeWidth="2.6"
            strokeLinecap="round"
          />

          {/* Active vertical guide line */}
          <line
            x1={activeCompPt.x}
            y1={chart.padTop}
            x2={activeCompPt.x}
            y2={chart.baselineY}
            stroke="#374151"
            strokeWidth="1"
            strokeDasharray="3 3"
          />

          {/* Interactive Points & X-axis Labels */}
          {data.map((d, i) => {
            const cPt = chart.completedPts[i];
            const crPt = chart.createdPts[i];
            const isActive = i === activeIdx;
            return (
              <g
                key={d.label}
                className="cursor-pointer"
                onMouseEnter={() => setHoveredIdx(i)}
                onClick={() => setHoveredIdx(i)}
              >
                <rect
                  x={cPt.x - 32}
                  y={chart.padTop}
                  width={64}
                  height={chart.baselineY - chart.padTop + 26}
                  fill="transparent"
                />

                <circle
                  cx={crPt.x}
                  cy={crPt.y}
                  r={isActive ? 5 : 3.5}
                  fill={isActive ? '#D9A05B' : '#14171B'}
                  stroke="#D9A05B"
                  strokeWidth="2"
                />
                <circle
                  cx={cPt.x}
                  cy={cPt.y}
                  r={isActive ? 5.5 : 3.5}
                  fill={isActive ? '#00D26A' : '#14171B'}
                  stroke="#00D26A"
                  strokeWidth="2"
                />

                <text
                  x={cPt.x}
                  y={chart.baselineY + 20}
                  textAnchor="middle"
                  className={`text-[11px] ${
                    isActive ? 'fill-[#F3F5F7] font-semibold' : 'fill-[#6B7280]'
                  }`}
                >
                  {d.label}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Floating Tooltip */}
        <div
          className="pointer-events-none absolute top-1 bg-[#1B2028] border border-[#2C333F] rounded-xl px-3 py-2 shadow-xl text-xs transition-all duration-150"
          style={{
            left: `clamp(12px, calc(${(activeCompPt.x / chart.width) * 100}% - 58px), calc(100% - 148px))`,
          }}
        >
          <div className="font-semibold text-[#F3F5F7] mb-1">{activeDatum.label}</div>
          <div className="flex items-center justify-between gap-4 text-[#9CA3AF]">
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#00D26A]" />
              Completed
            </span>
            <span className="font-mono font-semibold text-[#34D399] tabular-nums">
              {activeDatum.completed}
            </span>
          </div>
          <div className="flex items-center justify-between gap-4 text-[#9CA3AF] mt-0.5">
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#D9A05B]" />
              Created
            </span>
            <span className="font-mono font-semibold text-[#E5B87A] tabular-nums">
              {activeDatum.created}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
