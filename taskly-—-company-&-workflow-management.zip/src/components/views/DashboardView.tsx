import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clock,
  FileText,
  Folder,
  MessageSquare,
  Plus,
  RefreshCw,
  Send,
  ShieldAlert,
  TrendingUp,
  Users,
} from 'lucide-react';
import { useCompany } from '../../store/CompanyContext';
import { ProjectHealth, Timeframe } from '../../types';
import { Avatar } from '../Avatar';
import { ProjectIcon } from '../ProjectIcon';
import { TeamWorkloadDonut } from '../charts/TeamWorkloadDonut';
import { WorkflowAnalyticsChart } from '../charts/WorkflowAnalyticsChart';
import { MiniCalendarWidget } from '../widgets/MiniCalendarWidget';

interface DashboardViewProps {
  onOpenAddEmployee: () => void;
}

const HEALTH_META: Record<
  ProjectHealth,
  { textClass: string; bgClass: string; barClass: string; Icon: React.FC<{ className?: string }> }
> = {
  'On Track': {
    textClass: 'text-[#34D399]',
    bgClass: 'bg-[#00D26A]/10 border-[#00D26A]/25',
    barClass: 'bg-[#00D26A]',
    Icon: CheckCircle2,
  },
  'At Risk': {
    textClass: 'text-[#FBBF24]',
    bgClass: 'bg-amber-500/10 border-amber-500/25',
    barClass: 'bg-[#D9A05B]',
    Icon: AlertTriangle,
  },
  Delayed: {
    textClass: 'text-[#FB7185]',
    bgClass: 'bg-rose-500/10 border-rose-500/25',
    barClass: 'bg-rose-500',
    Icon: ShieldAlert,
  },
};

export const DashboardView: React.FC<DashboardViewProps> = ({ onOpenAddEmployee }) => {
  const {
    activeUser,
    projects,
    tasks,
    employees,
    activities,
    teamNotes,
    getProjectProgress,
    setActiveSection,
    setSelectedProjectId,
    setSelectedEmployeeId,
    postTeamNote,
  } = useCompany();

  const [timeframe, setTimeframe] = useState<Timeframe>('week');
  const [noteInput, setNoteInput] = useState('');

  const activeProjectsCount = projects.filter((p) => p.status !== 'Completed').length;
  const completedTasksCount = tasks.filter((t) => t.status === 'completed').length;
  const pendingTasksCount = tasks.filter((t) => t.status !== 'completed').length;
  const firstName = activeUser.name.split(' ')[0];

  const handlePostNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteInput.trim()) return;
    postTeamNote(noteInput);
    setNoteInput('');
  };

  const latestNote = teamNotes[0];
  const latestNoteAuthor = employees.find((e) => e.id === latestNote?.authorId) ?? employees[0];

  const activityBadge = (type: string) => {
    switch (type) {
      case 'completed':
        return { Icon: CheckCircle2, cls: 'bg-[#00D26A]/12 text-[#34D399]' };
      case 'comment':
        return { Icon: MessageSquare, cls: 'bg-[#D9A05B]/15 text-[#E5B87A]' };
      case 'file':
        return { Icon: FileText, cls: 'bg-emerald-500/12 text-emerald-300' };
      default:
        return { Icon: RefreshCw, cls: 'bg-sky-500/12 text-sky-400' };
    }
  };

  return (
    <div className="space-y-6">
      {/* Greeting & Timeframe Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-[26px] font-bold text-[#F3F5F7] tracking-tight">
            Good morning, {firstName}!
          </h1>
          <p className="text-sm text-[#9CA3AF] mt-0.5">
            FILLUPRO Software Tech Solutions · Live overview of company projects, roles, and tasks.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto">
          <span className="text-xs font-medium text-[#9CA3AF] hidden md:inline whitespace-nowrap">
            Fri, Nov 20, 2026
          </span>
          <div
            className="inline-flex items-center p-1 bg-[#14171B] border border-[#232933] rounded-xl"
            role="group"
            aria-label="Dashboard timeframe"
          >
            {(
              [
                { id: 'week', label: 'This Week' },
                { id: 'month', label: 'This Month' },
                { id: 'quarter', label: 'Quarter' },
              ] as { id: Timeframe; label: string }[]
            ).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setTimeframe(item.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  timeframe === item.id
                    ? 'bg-[#00D26A]/15 text-[#34D399] font-semibold'
                    : 'text-[#9CA3AF] hover:text-[#F3F5F7]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 4 KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <button
          type="button"
          onClick={() => setActiveSection('projects')}
          className="bg-[#14171B] border border-[#232933] hover:border-[#00D26A]/45 rounded-2xl p-4 flex items-center gap-4 text-left transition-colors"
        >
          <span className="w-12 h-12 rounded-2xl bg-[#00D26A]/12 text-[#00D26A] border border-[#00D26A]/20 inline-flex items-center justify-center shrink-0">
            <Folder className="w-5 h-5" />
          </span>
          <div className="min-w-0">
            <div className="text-xs font-medium text-[#9CA3AF]">Active Projects</div>
            <div className="font-display text-2xl font-bold text-[#F3F5F7] tabular-nums mt-0.5">
              {activeProjectsCount}
            </div>
            <div className="text-[11px] font-medium text-[#34D399] inline-flex items-center gap-1 mt-0.5">
              <TrendingUp className="w-3 h-3" />
              <span>+20% vs last month</span>
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection('tasks')}
          className="bg-[#14171B] border border-[#232933] hover:border-[#00D26A]/45 rounded-2xl p-4 flex items-center gap-4 text-left transition-colors"
        >
          <span className="w-12 h-12 rounded-2xl bg-emerald-500/12 text-[#34D399] border border-emerald-500/20 inline-flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </span>
          <div className="min-w-0">
            <div className="text-xs font-medium text-[#9CA3AF]">Tasks Completed</div>
            <div className="font-display text-2xl font-bold text-[#F3F5F7] tabular-nums mt-0.5">
              {completedTasksCount}
            </div>
            <div className="text-[11px] font-medium text-[#34D399] inline-flex items-center gap-1 mt-0.5">
              <TrendingUp className="w-3 h-3" />
              <span>+18% velocity gain</span>
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection('kanban')}
          className="bg-[#14171B] border border-[#232933] hover:border-[#D9A05B]/45 rounded-2xl p-4 flex items-center gap-4 text-left transition-colors"
        >
          <span className="w-12 h-12 rounded-2xl bg-[#D9A05B]/12 text-[#E5B87A] border border-[#D9A05B]/20 inline-flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5" />
          </span>
          <div className="min-w-0">
            <div className="text-xs font-medium text-[#9CA3AF]">Pending Tasks</div>
            <div className="font-display text-2xl font-bold text-[#F3F5F7] tabular-nums mt-0.5">
              {pendingTasksCount}
            </div>
            <div className="text-[11px] font-medium text-[#FB7185] mt-0.5">
              {tasks.filter((t) => t.priority === 'Urgent' && t.status !== 'completed').length} urgent
              priorities
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={() => setActiveSection('team')}
          className="bg-[#14171B] border border-[#232933] hover:border-[#00D26A]/45 rounded-2xl p-4 flex items-center gap-4 text-left transition-colors"
        >
          <span className="w-12 h-12 rounded-2xl bg-sky-500/12 text-sky-400 border border-sky-500/20 inline-flex items-center justify-center shrink-0">
            <Users className="w-5 h-5" />
          </span>
          <div className="min-w-0">
            <div className="text-xs font-medium text-[#9CA3AF]">Team Members</div>
            <div className="font-display text-2xl font-bold text-[#F3F5F7] tabular-nums mt-0.5">
              {employees.length}
            </div>
            <div className="text-[11px] font-medium text-[#34D399] mt-0.5">
              Across {new Set(employees.map((e) => e.department)).size} departments
            </div>
          </div>
        </button>
      </div>

      {/* Middle Row: Workflow Analytics + Calendar */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 items-stretch">
        <div className="xl:col-span-8 flex flex-col [&>*]:flex-1">
          <WorkflowAnalyticsChart timeframe={timeframe} />
        </div>
        <div className="xl:col-span-4 flex flex-col [&>*]:flex-1">
          <MiniCalendarWidget onViewAll={() => setActiveSection('calendar')} />
        </div>
      </div>

      {/* Lower Middle Row: Project Health + Team Workload */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 items-stretch">
        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="font-display text-[16px] font-bold text-[#F3F5F7]">
                  Project Health
                </h2>
                <p className="text-xs text-[#9CA3AF] mt-0.5">
                  Progress tracked live from assigned task statuses
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveSection('projects')}
                className="text-xs font-semibold text-[#34D399] hover:text-[#6EE7B7] inline-flex items-center gap-1 whitespace-nowrap"
              >
                View All
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-[#1F242C]">
              {projects.slice(0, 4).map((project) => {
                const progress = getProjectProgress(project);
                const meta = HEALTH_META[project.health];
                const StatusIcon = meta.Icon;
                return (
                  <button
                    key={project.id}
                    type="button"
                    onClick={() => setSelectedProjectId(project.id)}
                    className="w-full py-3 first:pt-1 last:pb-1 flex items-center justify-between gap-3 hover:bg-[#191E25] px-2 -mx-2 rounded-xl transition-colors text-left"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <ProjectIcon iconKey={project.iconKey} size="sm" />
                      <div className="min-w-0">
                        <div className="text-[13px] font-semibold text-[#F3F5F7] truncate">
                          {project.name}
                        </div>
                        <div className="text-[11px] text-[#9CA3AF] truncate">
                          {project.clientOrDept}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      <div className="w-20 sm:w-24 h-2 bg-[#1F242C] rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${meta.barClass}`}
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                      <span className="w-9 text-right text-xs font-mono font-semibold text-[#F3F5F7] tabular-nums">
                        {progress}%
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg border text-[11px] font-semibold w-[86px] justify-center ${meta.bgClass} ${meta.textClass}`}
                      >
                        <StatusIcon className="w-3 h-3 shrink-0" />
                        <span>{project.health}</span>
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <TeamWorkloadDonut
          timeframe={timeframe}
          onSelectDepartment={() => setActiveSection('team')}
        />
      </div>

      {/* Bottom Row: Recent Activity + Team Collaboration */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 items-stretch">
        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-[16px] font-bold text-[#F3F5F7]">Recent Activity</h2>
            <button
              type="button"
              onClick={() => setActiveSection('reports')}
              className="text-xs font-semibold text-[#34D399] hover:text-[#6EE7B7] inline-flex items-center gap-1"
            >
              View All
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-[#1F242C]">
            {activities.slice(0, 4).map((act) => {
              const actor = employees.find((e) => e.id === act.actorId) ?? employees[0];
              const badge = activityBadge(act.type);
              const BadgeIcon = badge.Icon;
              return (
                <div key={act.id} className="py-2.5 first:pt-1 last:pb-1 flex items-center gap-3">
                  <span
                    className={`w-8 h-8 rounded-xl inline-flex items-center justify-center shrink-0 ${badge.cls}`}
                  >
                    <BadgeIcon className="w-4 h-4" />
                  </span>
                  <button
                    type="button"
                    onClick={() => setSelectedEmployeeId(actor.id)}
                    className="shrink-0 rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00D26A]"
                    title={`Inspect ${actor.name}`}
                  >
                    <Avatar employee={actor} size="sm" />
                  </button>
                  <div className="min-w-0 flex-1">
                    <div className="text-[13px] font-semibold text-[#F3F5F7] truncate">
                      {actor.name}
                    </div>
                    <div className="text-xs text-[#9CA3AF] truncate">
                      {act.action} <span className="font-medium text-[#E5E7EB]">{act.target}</span>
                    </div>
                  </div>
                  <span className="text-[11px] text-[#6B7280] shrink-0 tabular-nums">
                    {act.timestamp}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-[16px] font-bold text-[#F3F5F7]">
                Team Collaboration
              </h2>
              <button
                type="button"
                onClick={onOpenAddEmployee}
                className="text-xs font-semibold text-[#34D399] hover:text-[#6EE7B7] inline-flex items-center gap-1"
              >
                Add Member
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex items-center justify-center flex-wrap gap-2 py-2">
              {employees.slice(0, 6).map((emp) => (
                <button
                  key={emp.id}
                  type="button"
                  onClick={() => setSelectedEmployeeId(emp.id)}
                  title={`${emp.name} — ${emp.roleTitle}`}
                  className="rounded-full transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00D26A]"
                >
                  <Avatar employee={emp} size="lg" />
                </button>
              ))}
              <button
                type="button"
                onClick={onOpenAddEmployee}
                aria-label="Add new employee"
                className="w-11 h-11 rounded-full border border-dashed border-[#374151] text-[#9CA3AF] hover:border-[#00D26A] hover:text-[#34D399] inline-flex items-center justify-center transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <p className="text-center text-xs text-[#9CA3AF] mt-2 mb-4">
              <span className="font-semibold text-[#F3F5F7] tabular-nums">{employees.length}</span>{' '}
              team members working together across{' '}
              <span className="font-semibold text-[#F3F5F7] tabular-nums">
                {projects.length}
              </span>{' '}
              projects
            </p>
          </div>

          <div className="space-y-3">
            {latestNote && (
              <div className="bg-[#181C22] border border-[#252B35] rounded-xl p-3.5">
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2 min-w-0">
                    <Avatar employee={latestNoteAuthor} size="xs" />
                    <span className="text-xs font-semibold text-[#F3F5F7] truncate">
                      {latestNoteAuthor.name}
                    </span>
                    <span className="text-[11px] text-[#9CA3AF] truncate">
                      {latestNoteAuthor.roleTitle}
                    </span>
                  </div>
                  <span className="text-[11px] text-[#6B7280] shrink-0">
                    {latestNote.timestamp}
                  </span>
                </div>
                <p className="text-xs text-[#D1D5DB] leading-relaxed">{latestNote.message}</p>
              </div>
            )}

            <form onSubmit={handlePostNote} className="flex items-center gap-2">
              <input
                type="text"
                value={noteInput}
                onChange={(e) => setNoteInput(e.target.value)}
                placeholder="Post an update for the team..."
                className="flex-1 bg-[#181C22] border border-[#252B35] focus:border-[#00D26A]/70 rounded-xl px-3 py-2 text-xs text-[#F3F5F7] placeholder:text-[#6B7280] focus:outline-none"
              />
              <button
                type="submit"
                disabled={!noteInput.trim()}
                className="px-3.5 py-2 rounded-xl text-xs font-bold bg-[#00D26A] hover:bg-[#10E077] text-[#051B0E] disabled:opacity-40 inline-flex items-center gap-1 transition-colors shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
