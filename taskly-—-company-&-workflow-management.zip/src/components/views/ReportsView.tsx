import React, { useMemo } from 'react';
import { Download } from 'lucide-react';
import { useCompany } from '../../store/CompanyContext';
import { Avatar } from '../Avatar';

export const ReportsView: React.FC = () => {
  const { projects, tasks, employees, activities, getProjectProgress } = useCompany();

  const metrics = useMemo(() => {
    const totalHoursEst = tasks.reduce((a, t) => a + t.estimatedHours, 0);
    const totalHoursLogged = tasks.reduce((a, t) => a + t.loggedHours, 0);
    const completionRate =
      tasks.length > 0
        ? Math.round((tasks.filter((t) => t.status === 'completed').length / tasks.length) * 100)
        : 0;
    const totalBudget = projects.reduce((a, p) => a + p.budget, 0);
    const totalSpent = projects.reduce((a, p) => a + p.spent, 0);

    return { totalHoursEst, totalHoursLogged, completionRate, totalBudget, totalSpent };
  }, [tasks, projects]);

  const exportCsv = () => {
    const header = ['Code', 'Title', 'Project', 'Assignee', 'Role', 'Status', 'Priority', 'DueDate'];
    const rows = tasks.map((t) => {
      const p = projects.find((pr) => pr.id === t.projectId)?.name ?? '';
      const e = employees.find((em) => em.id === t.assigneeId);
      return [
        t.code,
        `"${t.title.replace(/"/g, '""')}"`,
        `"${p.replace(/"/g, '""')}"`,
        `"${e?.name ?? ''}"`,
        `"${e?.roleTitle ?? ''}"`,
        t.status,
        t.priority,
        t.dueDate,
      ].join(',');
    });
    const csv = [header.join(','), ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'fillupro-company-progress-report.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#F3F5F7] tracking-tight">
            Progress Reports &amp; Analytics
          </h1>
          <p className="text-sm text-[#9CA3AF] mt-0.5">
            Company-wide delivery velocity, employee execution metrics, and budget tracking.
          </p>
        </div>

        <button
          type="button"
          onClick={exportCsv}
          className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-[#14171B] border border-[#252B35] hover:border-[#00D26A] text-[#F3F5F7] inline-flex items-center gap-2 self-start sm:self-auto whitespace-nowrap shrink-0 transition-colors"
        >
          <Download className="w-4 h-4 text-[#00D26A]" />
          Export CSV Report
        </button>
      </div>

      {/* Top KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-4">
          <div className="text-xs text-[#9CA3AF]">Overall Task Completion</div>
          <div className="font-display text-2xl font-bold text-[#F3F5F7] tabular-nums mt-1">
            {metrics.completionRate}%
          </div>
          <div className="text-[11px] text-[#34D399] mt-0.5 tabular-nums">
            {tasks.filter((t) => t.status === 'completed').length} of {tasks.length} tasks done
          </div>
        </div>

        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-4">
          <div className="text-xs text-[#9CA3AF]">Logged vs Estimated Hours</div>
          <div className="font-display text-2xl font-bold text-[#F3F5F7] tabular-nums mt-1">
            {metrics.totalHoursLogged}h / {metrics.totalHoursEst}h
          </div>
          <div className="text-[11px] text-[#9CA3AF] mt-0.5 tabular-nums">
            {Math.round((metrics.totalHoursLogged / Math.max(1, metrics.totalHoursEst)) * 100)}%
            effort burned
          </div>
        </div>

        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-4">
          <div className="text-xs text-[#9CA3AF]">Portfolio Spend</div>
          <div className="font-display text-2xl font-bold text-[#F3F5F7] tabular-nums mt-1">
            ${metrics.totalSpent.toLocaleString()}
          </div>
          <div className="text-[11px] text-[#9CA3AF] mt-0.5 tabular-nums">
            of ${metrics.totalBudget.toLocaleString()} allocated
          </div>
        </div>

        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-4">
          <div className="text-xs text-[#9CA3AF]">Projects On Track</div>
          <div className="font-display text-2xl font-bold text-[#F3F5F7] tabular-nums mt-1">
            {projects.filter((p) => p.health === 'On Track').length} / {projects.length}
          </div>
          <div className="text-[11px] text-[#FBBF24] mt-0.5 tabular-nums">
            {projects.filter((p) => p.health !== 'On Track').length} requiring attention
          </div>
        </div>
      </div>

      {/* Employee Performance & Project Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-5">
          <h2 className="font-display text-base font-bold text-[#F3F5F7] mb-4">
            Project Progress &amp; Budget Breakdown
          </h2>
          <div className="space-y-4">
            {projects.map((p) => {
              const prog = getProjectProgress(p);
              const budgetPct = Math.min(100, Math.round((p.spent / Math.max(1, p.budget)) * 100));
              return (
                <div key={p.id} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#F3F5F7]">{p.name}</span>
                    <span className="text-[#9CA3AF] font-mono tabular-nums">
                      {prog}% complete · ${p.spent.toLocaleString()} / ${p.budget.toLocaleString()} (
                      {budgetPct}%)
                    </span>
                  </div>
                  <div className="w-full h-2 bg-[#1F242C] rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full bg-[#00D26A]"
                      style={{ width: `${prog}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-5">
          <h2 className="font-display text-base font-bold text-[#F3F5F7] mb-4">
            Employee Delivery Leaderboard
          </h2>
          <div className="divide-y divide-[#1F242C]">
            {employees.map((emp) => {
              const empTasks = tasks.filter((t) => t.assigneeId === emp.id);
              const done = empTasks.filter((t) => t.status === 'completed').length;
              const hours = empTasks.reduce((a, t) => a + t.loggedHours, 0);
              return (
                <div key={emp.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Avatar employee={emp} size="sm" />
                    <div className="min-w-0">
                      <div className="font-semibold text-[#F3F5F7] truncate">{emp.name}</div>
                      <div className="text-[11px] text-[#9CA3AF] truncate">
                        {emp.roleTitle} · {emp.department}
                      </div>
                    </div>
                  </div>
                  <div className="text-right font-mono tabular-nums shrink-0">
                    <div className="font-semibold text-[#34D399]">
                      {done}/{empTasks.length} tasks
                    </div>
                    <div className="text-[11px] text-[#9CA3AF]">{hours}h logged</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Full Activity Audit Log */}
      <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-5">
        <h2 className="font-display text-base font-bold text-[#F3F5F7] mb-3">
          Recent Workspace Activity Log
        </h2>
        <div className="divide-y divide-[#1F242C]">
          {activities.map((act) => {
            const actor = employees.find((e) => e.id === act.actorId) ?? employees[0];
            return (
              <div key={act.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2.5 min-w-0">
                  <Avatar employee={actor} size="xs" />
                  <span className="truncate text-[#D1D5DB]">
                    <strong className="text-[#F3F5F7]">{actor.name}</strong> {act.action}{' '}
                    <strong className="text-[#34D399]">{act.target}</strong>
                  </span>
                </div>
                <span className="text-[11px] text-[#6B7280] shrink-0 tabular-nums">
                  {act.timestamp}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
