import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Circle,
  Clock,
  Filter,
  Plus,
  Search,
  Sparkles,
} from 'lucide-react';
import { useCompany } from '../../store/CompanyContext';
import { TaskPriority, TaskStatus } from '../../types';
import { Avatar } from '../Avatar';

interface TasksViewProps {
  onOpenNewTask: () => void;
}

const STATUS_OPTIONS: { value: TaskStatus; label: string }[] = [
  { value: 'todo', label: 'To Do' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'in_review', label: 'In Review' },
  { value: 'completed', label: 'Completed' },
];

const PRIORITY_META: Record<TaskPriority, { color: string }> = {
  Urgent: { color: 'text-[#FB7185]' },
  High: { color: 'text-[#FBBF24]' },
  Medium: { color: 'text-[#34D399]' },
  Low: { color: 'text-[#9CA3AF]' },
};

export const TasksView: React.FC<TasksViewProps> = ({ onOpenNewTask }) => {
  const {
    tasks,
    projects,
    employees,
    activeUser,
    moveTaskStatus,
    setSelectedTaskId,
    setSelectedEmployeeId,
    setSelectedProjectId,
  } = useCompany();

  const [scope, setScope] = useState<'all' | 'mine'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | TaskStatus>('all');
  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [search, setSearch] = useState('');

  const filteredTasks = useMemo(() => {
    const q = search.trim().toLowerCase();
    return tasks.filter((t) => {
      if (scope === 'mine' && t.assigneeId !== activeUser.id) return false;
      if (statusFilter !== 'all' && t.status !== statusFilter) return false;
      if (projectFilter !== 'all' && t.projectId !== projectFilter) return false;
      if (!q) return true;
      return (
        t.title.toLowerCase().includes(q) ||
        t.code.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q)
      );
    });
  }, [tasks, scope, activeUser.id, statusFilter, projectFilter, search]);

  const statusIcon = (status: TaskStatus) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-[#00D26A]" />;
      case 'in_review':
        return <Sparkles className="w-4 h-4 text-[#D9A05B]" />;
      case 'in_progress':
        return <Clock className="w-4 h-4 text-sky-400" />;
      default:
        return <Circle className="w-4 h-4 text-[#6B7280]" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#F3F5F7] tracking-tight">
            Tasks &amp; Deliverables
          </h1>
          <p className="text-sm text-[#9CA3AF] mt-0.5">
            Assign ownership, track subtask completion, and update progress across all company workstreams.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenNewTask}
          className="px-4 py-2.5 rounded-xl text-xs font-bold bg-[#00D26A] hover:bg-[#10E077] text-[#051B0E] inline-flex items-center gap-2 transition-colors self-start sm:self-auto whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          New Task
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex p-1 bg-[#181C22] border border-[#252B35] rounded-xl">
            <button
              type="button"
              onClick={() => setScope('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                scope === 'all'
                  ? 'bg-[#232933] text-[#F3F5F7] font-semibold'
                  : 'text-[#9CA3AF]'
              }`}
            >
              All Company ({tasks.length})
            </button>
            <button
              type="button"
              onClick={() => setScope('mine')}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                scope === 'mine'
                  ? 'bg-[#232933] text-[#F3F5F7] font-semibold'
                  : 'text-[#9CA3AF]'
              }`}
            >
              Assigned to {activeUser.name.split(' ')[0]} (
              {tasks.filter((t) => t.assigneeId === activeUser.id).length})
            </button>
          </div>

          <div className="inline-flex items-center gap-1 flex-wrap">
            {(['all', 'todo', 'in_progress', 'in_review', 'completed'] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1.5 rounded-xl text-xs font-medium transition-colors whitespace-nowrap ${
                  statusFilter === st
                    ? 'bg-[#00D26A]/15 text-[#34D399] font-semibold'
                    : 'text-[#9CA3AF] hover:bg-[#1A1F26]'
                }`}
              >
                {st === 'all'
                  ? 'All States'
                  : STATUS_OPTIONS.find((o) => o.value === st)?.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-1.5 bg-[#181C22] border border-[#252B35] rounded-xl px-2.5 py-1.5">
            <Filter className="w-3.5 h-3.5 text-[#6B7280]" />
            <select
              value={projectFilter}
              onChange={(e) => setProjectFilter(e.target.value)}
              aria-label="Filter by project"
              className="bg-transparent text-xs text-[#E5E7EB] focus:outline-none"
            >
              <option value="all" className="bg-[#15191F]">
                All Projects
              </option>
              {projects.map((p) => (
                <option key={p.id} value={p.id} className="bg-[#15191F]">
                  {p.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-1.5 min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-[#6B7280]" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search tasks or ID..."
              className="bg-transparent text-xs text-[#F3F5F7] placeholder:text-[#6B7280] focus:outline-none w-full"
            />
          </div>
        </div>
      </div>

      {/* High-Density Task Table */}
      <div className="bg-[#14171B] border border-[#232933] rounded-2xl overflow-hidden">
        {filteredTasks.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-sm font-semibold text-[#F3F5F7]">No tasks match these filters</p>
            <p className="text-xs text-[#9CA3AF] mt-1 mb-4">
              Adjust your search or create a new task to assign to a team member.
            </p>
            <button
              type="button"
              onClick={onOpenNewTask}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#00D26A]/15 text-[#34D399] hover:bg-[#00D26A]/25"
            >
              Create Task
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#232933] bg-[#181C22] text-[11px] font-semibold text-[#9CA3AF]">
                  <th className="py-3 px-4">Task</th>
                  <th className="py-3 px-3">Project</th>
                  <th className="py-3 px-3">Assignee &amp; Role</th>
                  <th className="py-3 px-3">Priority</th>
                  <th className="py-3 px-3">Subtasks</th>
                  <th className="py-3 px-3">Hours</th>
                  <th className="py-3 px-3">Due Date</th>
                  <th className="py-3 px-4 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1F242C] text-xs">
                {filteredTasks.map((task) => {
                  const project = projects.find((p) => p.id === task.projectId);
                  const assignee = employees.find((e) => e.id === task.assigneeId);
                  const doneSubs = task.subtasks.filter((s) => s.done).length;
                  return (
                    <tr
                      key={task.id}
                      className="hover:bg-[#191E25] transition-colors group"
                    >
                      <td className="py-3 px-4 max-w-[300px]">
                        <button
                          type="button"
                          onClick={() => setSelectedTaskId(task.id)}
                          className="flex items-start gap-2.5 text-left w-full"
                        >
                          <span className="mt-0.5 shrink-0">{statusIcon(task.status)}</span>
                          <div className="min-w-0">
                            <div className="font-semibold text-[#F3F5F7] group-hover:text-[#34D399] truncate">
                              {task.title}
                            </div>
                            <div className="text-[11px] font-mono text-[#6B7280] mt-0.5">
                              {task.code}
                            </div>
                          </div>
                        </button>
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        {project ? (
                          <button
                            type="button"
                            onClick={() => setSelectedProjectId(project.id)}
                            className="text-xs font-medium text-[#D1D5DB] hover:text-[#34D399]"
                          >
                            {project.name}
                          </button>
                        ) : (
                          <span className="text-[#6B7280]">—</span>
                        )}
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        {assignee ? (
                          <button
                            type="button"
                            onClick={() => setSelectedEmployeeId(assignee.id)}
                            className="flex items-center gap-2 text-left hover:text-[#34D399]"
                          >
                            <Avatar employee={assignee} size="xs" />
                            <div>
                              <div className="font-medium text-[#F3F5F7] leading-tight">
                                {assignee.name}
                              </div>
                              <div className="text-[10px] text-[#9CA3AF]">{assignee.roleTitle}</div>
                            </div>
                          </button>
                        ) : (
                          <span className="text-[#6B7280]">Unassigned</span>
                        )}
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 font-semibold ${
                            PRIORITY_META[task.priority].color
                          }`}
                        >
                          <AlertCircle className="w-3.5 h-3.5" />
                          {task.priority}
                        </span>
                      </td>

                      <td className="py-3 px-3 font-mono tabular-nums text-[#D1D5DB] whitespace-nowrap">
                        {task.subtasks.length > 0 ? `${doneSubs}/${task.subtasks.length}` : '—'}
                      </td>

                      <td className="py-3 px-3 font-mono tabular-nums text-[#D1D5DB] whitespace-nowrap">
                        {task.loggedHours}/{task.estimatedHours}h
                      </td>

                      <td className="py-3 px-3 font-mono tabular-nums text-[#9CA3AF] whitespace-nowrap">
                        {task.dueDate}
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <select
                          value={task.status}
                          onChange={(e) => moveTaskStatus(task.id, e.target.value as TaskStatus)}
                          aria-label={`Change status for ${task.title}`}
                          className="bg-[#181C22] border border-[#2A313D] hover:border-[#00D26A]/60 rounded-lg px-2 py-1 text-xs font-medium text-[#F3F5F7] focus:outline-none focus:ring-2 focus:ring-[#00D26A]"
                        >
                          {STATUS_OPTIONS.map((opt) => (
                            <option key={opt.value} value={opt.value} className="bg-[#15191F]">
                              {opt.label}
                            </option>
                          ))}
                        </select>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
