import React, { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Flag, Plus } from 'lucide-react';
import { useCompany } from '../../store/CompanyContext';
import { Avatar } from '../Avatar';

interface CalendarViewProps {
  onOpenNewTask: (prefillDate?: string) => void;
}

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export const CalendarView: React.FC<CalendarViewProps> = ({ onOpenNewTask }) => {
  const { tasks, projects, employees, setSelectedTaskId, setSelectedProjectId } = useCompany();
  const [year, setYear] = useState(2026);
  const [month, setMonth] = useState(10);
  const [selectedDay, setSelectedDay] = useState('2026-11-20');

  const gridDays = useMemo(() => {
    const firstDay = new Date(year, month, 1).getDay();
    const totalDays = new Date(year, month + 1, 0).getDate();
    const prevTotal = new Date(year, month, 0).getDate();
    const cells: { dateStr: string; dayNum: number; inMonth: boolean }[] = [];

    for (let i = firstDay - 1; i >= 0; i--) {
      const d = prevTotal - i;
      const prevM = month === 0 ? 11 : month - 1;
      const prevY = month === 0 ? year - 1 : year;
      cells.push({
        dateStr: `${prevY}-${String(prevM + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`,
        dayNum: d,
        inMonth: false,
      });
    }

    for (let d = 1; d <= totalDays; d++) {
      cells.push({
        dateStr: `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`,
        dayNum: d,
        inMonth: true,
      });
    }

    const rem = 35 - cells.length;
    const needed = rem >= 0 ? rem : 42 - cells.length;
    for (let d = 1; d <= needed; d++) {
      const nextM = month === 11 ? 0 : month + 1;
      const nextY = month === 11 ? year + 1 : year;
      cells.push({
        dateStr: `${nextY}-${String(nextM + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`,
        dayNum: d,
        inMonth: false,
      });
    }
    return cells;
  }, [year, month]);

  const shiftMonth = (delta: number) => {
    const next = new Date(year, month + delta, 1);
    setYear(next.getFullYear());
    setMonth(next.getMonth());
  };

  const selectedTasks = tasks.filter((t) => t.dueDate === selectedDay);
  const selectedMilestones = projects.flatMap((p) =>
    p.milestones
      .filter((m) => m.dueDate === selectedDay)
      .map((m) => ({ ...m, projectName: p.name, projectId: p.id }))
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#F3F5F7] tracking-tight">
            Schedule &amp; Deadlines
          </h1>
          <p className="text-sm text-[#9CA3AF] mt-0.5">
            Track project milestones and task due dates across your team calendar.
          </p>
        </div>

        <button
          type="button"
          onClick={() => onOpenNewTask(selectedDay)}
          className="px-4 py-2.5 rounded-xl text-xs font-bold bg-[#00D26A] hover:bg-[#10E077] text-[#051B0E] inline-flex items-center gap-2 transition-colors self-start sm:self-auto whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          Schedule Task for {selectedDay}
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 items-start">
        <div className="xl:col-span-8 bg-[#14171B] border border-[#232933] rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-lg font-bold text-[#F3F5F7]">
              {MONTHS[month]} {year}
            </h2>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => shiftMonth(-1)}
                className="p-2 rounded-xl border border-[#252B35] text-[#9CA3AF] hover:bg-[#1C2129] hover:text-white"
                aria-label="Previous month"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setYear(2026);
                  setMonth(10);
                  setSelectedDay('2026-11-20');
                }}
                className="px-3 py-1.5 rounded-xl border border-[#252B35] text-xs font-semibold text-[#D1D5DB] hover:bg-[#1C2129]"
              >
                Today
              </button>
              <button
                type="button"
                onClick={() => shiftMonth(1)}
                className="p-2 rounded-xl border border-[#252B35] text-[#9CA3AF] hover:bg-[#1C2129] hover:text-white"
                aria-label="Next month"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-7 border-b border-[#232933] pb-2 mb-2 text-center">
            {WEEKDAYS.map((d) => (
              <span key={d} className="text-xs font-semibold text-[#9CA3AF]">
                {d}
              </span>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1.5">
            {gridDays.map((cell) => {
              const dayTasks = tasks.filter((t) => t.dueDate === cell.dateStr);
              const dayMilestones = projects.flatMap((p) =>
                p.milestones.filter((m) => m.dueDate === cell.dateStr)
              );
              const isSelected = cell.dateStr === selectedDay;
              return (
                <button
                  key={cell.dateStr}
                  type="button"
                  onClick={() => setSelectedDay(cell.dateStr)}
                  className={`min-h-[82px] p-2 rounded-xl border text-left flex flex-col justify-between transition-colors ${
                    isSelected
                      ? 'border-[#00D26A] bg-[#00D26A]/10'
                      : cell.inMonth
                      ? 'border-[#1F242C] bg-[#161A20] hover:border-[#00D26A]/40'
                      : 'border-transparent bg-[#111418] text-[#4B5563]'
                  }`}
                >
                  <span
                    className={`w-6 h-6 rounded-full inline-flex items-center justify-center text-xs tabular-nums ${
                      isSelected
                        ? 'bg-[#00D26A] text-[#051B0E] font-bold'
                        : cell.inMonth
                        ? 'text-[#F3F5F7] font-semibold'
                        : 'text-[#4B5563]'
                    }`}
                  >
                    {cell.dayNum}
                  </span>

                  <div className="space-y-1 mt-1">
                    {dayMilestones.slice(0, 1).map((m) => (
                      <div
                        key={m.id}
                        className="text-[10px] font-semibold text-[#E5B87A] truncate"
                      >
                        ★ {m.title}
                      </div>
                    ))}
                    {dayTasks.slice(0, 2).map((t) => (
                      <div
                        key={t.id}
                        className="text-[10px] font-medium text-[#D1D5DB] truncate"
                      >
                        {t.code} · {t.title}
                      </div>
                    ))}
                    {dayTasks.length > 2 && (
                      <div className="text-[10px] text-[#6B7280]">
                        +{dayTasks.length - 2} more
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Day Panel */}
        <div className="xl:col-span-4 bg-[#14171B] border border-[#232933] rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-[#1F242C] pb-3">
            <div>
              <h3 className="font-display text-base font-bold text-[#F3F5F7]">
                Agenda · {selectedDay}
              </h3>
              <p className="text-xs text-[#9CA3AF]">
                {selectedTasks.length} tasks · {selectedMilestones.length} milestones
              </p>
            </div>
          </div>

          {selectedMilestones.length > 0 && (
            <div className="space-y-2">
              <div className="text-[11px] font-semibold text-[#E5B87A]">Project Milestones</div>
              {selectedMilestones.map((ms) => (
                <button
                  key={ms.id}
                  type="button"
                  onClick={() => setSelectedProjectId(ms.projectId)}
                  className="w-full text-left p-3 rounded-xl bg-[#D9A05B]/10 border border-[#D9A05B]/25 hover:border-[#D9A05B]/50"
                >
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#F3F5F7]">
                    <Flag className="w-3.5 h-3.5 text-[#E5B87A] shrink-0" />
                    <span className="truncate">{ms.title}</span>
                  </div>
                  <div className="text-[11px] text-[#E5B87A] mt-0.5">{ms.projectName}</div>
                </button>
              ))}
            </div>
          )}

          <div className="space-y-2">
            <div className="text-[11px] font-semibold text-[#9CA3AF]">Due Tasks</div>
            {selectedTasks.length === 0 ? (
              <p className="text-xs text-[#6B7280] py-4">
                No tasks scheduled on this date. Use the button above to add one.
              </p>
            ) : (
              selectedTasks.map((t) => {
                const assignee = employees.find((e) => e.id === t.assigneeId);
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setSelectedTaskId(t.id)}
                    className="w-full text-left p-3 rounded-xl bg-[#181C22] border border-[#252B35] hover:border-[#00D26A]/50 transition-colors"
                  >
                    <div className="flex items-center justify-between text-[11px] text-[#9CA3AF] mb-1">
                      <span className="font-mono text-[#34D399] font-semibold">{t.code}</span>
                      <span>{t.priority}</span>
                    </div>
                    <div className="text-xs font-semibold text-[#F3F5F7] mb-2">{t.title}</div>
                    {assignee && (
                      <div className="flex items-center gap-2 text-[11px] text-[#9CA3AF]">
                        <Avatar employee={assignee} size="xs" />
                        <span>{assignee.name}</span>
                      </div>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
