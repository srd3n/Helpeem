import React, { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import { useCompany } from '../../store/CompanyContext';
import { TaskStatus } from '../../types';
import { Avatar } from '../Avatar';

interface KanbanViewProps {
  onOpenNewTask: () => void;
}

const COLUMNS: { id: TaskStatus; title: string; accent: string }[] = [
  { id: 'todo', title: 'To Do', accent: 'bg-[#6B7280]' },
  { id: 'in_progress', title: 'In Progress', accent: 'bg-sky-400' },
  { id: 'in_review', title: 'In Review', accent: 'bg-[#D9A05B]' },
  { id: 'completed', title: 'Completed', accent: 'bg-[#00D26A]' },
];

export const KanbanView: React.FC<KanbanViewProps> = ({ onOpenNewTask }) => {
  const {
    tasks,
    projects,
    employees,
    moveTaskStatus,
    setSelectedTaskId,
    setSelectedEmployeeId,
  } = useCompany();

  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [draggedId, setDraggedId] = useState<string | null>(null);
  const [dragOverCol, setDragOverCol] = useState<TaskStatus | null>(null);

  const visibleTasks = useMemo(
    () =>
      tasks.filter((t) => (projectFilter === 'all' ? true : t.projectId === projectFilter)),
    [tasks, projectFilter]
  );

  const handleDrop = (colId: TaskStatus) => {
    if (draggedId) {
      moveTaskStatus(draggedId, colId);
    }
    setDraggedId(null);
    setDragOverCol(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#F3F5F7] tracking-tight">
            Kanban Workflow Board
          </h1>
          <p className="text-sm text-[#9CA3AF] mt-0.5">
            Drag cards or use stage controls to advance tasks and automatically update project progress.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto">
          <select
            value={projectFilter}
            onChange={(e) => setProjectFilter(e.target.value)}
            aria-label="Filter board by project"
            className="bg-[#14171B] border border-[#232933] rounded-xl px-3 py-2 text-xs font-medium text-[#E5E7EB] focus:outline-none focus:ring-2 focus:ring-[#00D26A]"
          >
            <option value="all" className="bg-[#15191F]">
              All Projects ({projects.length})
            </option>
            {projects.map((p) => (
              <option key={p.id} value={p.id} className="bg-[#15191F]">
                {p.name}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={onOpenNewTask}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-[#00D26A] hover:bg-[#10E077] text-[#051B0E] inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            Add Task
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 items-start">
        {COLUMNS.map((col, colIdx) => {
          const colTasks = visibleTasks.filter((t) => t.status === col.id);
          const isOver = dragOverCol === col.id;
          return (
            <div
              key={col.id}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOverCol(col.id);
              }}
              onDragLeave={() => setDragOverCol(null)}
              onDrop={() => handleDrop(col.id)}
              className={`bg-[#111418] border rounded-2xl p-3.5 min-h-[420px] transition-colors ${
                isOver ? 'border-[#00D26A] bg-[#00D26A]/5' : 'border-[#202630]'
              }`}
            >
              <div className="flex items-center justify-between mb-3 px-1">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${col.accent}`} />
                  <h2 className="font-display text-sm font-bold text-[#F3F5F7]">{col.title}</h2>
                </div>
                <span className="text-xs font-mono font-semibold text-[#9CA3AF] tabular-nums">
                  {colTasks.length}
                </span>
              </div>

              <div className="space-y-3">
                {colTasks.map((task) => {
                  const project = projects.find((p) => p.id === task.projectId);
                  const assignee = employees.find((e) => e.id === task.assigneeId);
                  const doneSubs = task.subtasks.filter((s) => s.done).length;
                  return (
                    <div
                      key={task.id}
                      draggable
                      onDragStart={() => setDraggedId(task.id)}
                      onDragEnd={() => {
                        setDraggedId(null);
                        setDragOverCol(null);
                      }}
                      className="bg-[#161A20] border border-[#252B35] hover:border-[#00D26A]/50 rounded-xl p-3.5 cursor-grab active:cursor-grabbing transition-colors"
                    >
                      <div className="flex items-center justify-between gap-2 text-[11px] text-[#9CA3AF] mb-1.5">
                        <span className="font-mono font-semibold text-[#34D399]">{task.code}</span>
                        <span
                          className={`font-semibold ${
                            task.priority === 'Urgent'
                              ? 'text-[#FB7185]'
                              : task.priority === 'High'
                              ? 'text-[#FBBF24]'
                              : 'text-[#9CA3AF]'
                          }`}
                        >
                          {task.priority}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => setSelectedTaskId(task.id)}
                        className="text-left w-full font-semibold text-[13px] text-[#F3F5F7] hover:text-[#34D399] leading-snug mb-2"
                      >
                        {task.title}
                      </button>

                      <div className="flex items-center justify-between text-[11px] text-[#9CA3AF] mb-3">
                        <span className="truncate max-w-[140px]">{project?.name}</span>
                        {task.subtasks.length > 0 && (
                          <span className="font-mono tabular-nums">
                            {doneSubs}/{task.subtasks.length} steps
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between pt-2.5 border-t border-[#222832]">
                        {assignee ? (
                          <button
                            type="button"
                            onClick={() => setSelectedEmployeeId(assignee.id)}
                            className="flex items-center gap-1.5 text-xs text-[#D1D5DB] hover:text-white min-w-0"
                            title={`${assignee.name} · ${assignee.roleTitle}`}
                          >
                            <Avatar employee={assignee} size="xs" />
                            <span className="truncate max-w-[95px]">
                              {assignee.name.split(' ')[0]}
                            </span>
                          </button>
                        ) : (
                          <span className="text-[11px] text-[#6B7280]">Unassigned</span>
                        )}

                        <div className="flex items-center gap-1">
                          {colIdx > 0 && (
                            <button
                              type="button"
                              onClick={() => moveTaskStatus(task.id, COLUMNS[colIdx - 1].id)}
                              title={`Move back to ${COLUMNS[colIdx - 1].title}`}
                              className="p-1 rounded-lg text-[#9CA3AF] hover:bg-[#232933] hover:text-white"
                            >
                              <ChevronLeft className="w-3.5 h-3.5" />
                            </button>
                          )}
                          {colIdx < COLUMNS.length - 1 && (
                            <button
                              type="button"
                              onClick={() => moveTaskStatus(task.id, COLUMNS[colIdx + 1].id)}
                              title={`Advance to ${COLUMNS[colIdx + 1].title}`}
                              className="p-1 rounded-lg text-[#9CA3AF] hover:bg-[#00D26A]/15 hover:text-[#34D399]"
                            >
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
