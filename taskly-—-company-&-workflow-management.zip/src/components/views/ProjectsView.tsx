import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Calendar,
  CheckCircle2,
  DollarSign,
  FolderPlus,
  Search,
  ShieldAlert,
} from 'lucide-react';
import { useCompany } from '../../store/CompanyContext';
import { ProjectHealth } from '../../types';
import { Avatar } from '../Avatar';
import { ProjectIcon } from '../ProjectIcon';

interface ProjectsViewProps {
  onOpenNewProject: () => void;
}

const HEALTH_STYLE: Record<
  ProjectHealth,
  { badge: string; bar: string; Icon: React.FC<{ className?: string }> }
> = {
  'On Track': {
    badge: 'bg-[#00D26A]/10 text-[#34D399] border-[#00D26A]/25',
    bar: 'bg-[#00D26A]',
    Icon: CheckCircle2,
  },
  'At Risk': {
    badge: 'bg-amber-500/10 text-[#FBBF24] border-amber-500/25',
    bar: 'bg-[#D9A05B]',
    Icon: AlertTriangle,
  },
  Delayed: {
    badge: 'bg-rose-500/10 text-[#FB7185] border-rose-500/25',
    bar: 'bg-rose-500',
    Icon: ShieldAlert,
  },
};

export const ProjectsView: React.FC<ProjectsViewProps> = ({ onOpenNewProject }) => {
  const {
    projects,
    tasks,
    employees,
    getProjectProgress,
    setSelectedProjectId,
    setSelectedEmployeeId,
  } = useCompany();

  const [healthFilter, setHealthFilter] = useState<'All' | ProjectHealth>('All');
  const [search, setSearch] = useState('');

  const filteredProjects = useMemo(() => {
    const q = search.trim().toLowerCase();
    return projects.filter((p) => {
      if (healthFilter !== 'All' && p.health !== healthFilter) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.clientOrDept.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
      );
    });
  }, [projects, healthFilter, search]);

  const totalBudget = projects.reduce((acc, p) => acc + p.budget, 0);
  const totalSpent = projects.reduce((acc, p) => acc + p.spent, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#F3F5F7] tracking-tight">
            Company Projects
          </h1>
          <p className="text-sm text-[#9CA3AF] mt-0.5">
            Track project milestones, budgets, task completion progress, and delivery health.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenNewProject}
          className="px-4 py-2.5 rounded-xl text-xs font-bold bg-[#00D26A] hover:bg-[#10E077] text-[#051B0E] inline-flex items-center gap-2 transition-colors self-start sm:self-auto whitespace-nowrap shrink-0"
        >
          <FolderPlus className="w-4 h-4" />
          New Project
        </button>
      </div>

      {/* Summary & Filters Bar */}
      <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          {(['All', 'On Track', 'At Risk', 'Delayed'] as const).map((status) => {
            const count =
              status === 'All'
                ? projects.length
                : projects.filter((p) => p.health === status).length;
            return (
              <button
                key={status}
                type="button"
                onClick={() => setHealthFilter(status)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  healthFilter === status
                    ? 'bg-[#00D26A]/15 text-[#34D399] font-semibold border border-[#00D26A]/30'
                    : 'bg-[#191D24] text-[#9CA3AF] hover:text-[#F3F5F7] border border-transparent'
                }`}
              >
                {status} ({count})
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2 text-xs text-[#9CA3AF]">
            <DollarSign className="w-4 h-4 text-[#00D26A]" />
            <span>
              Budget Utilization:{' '}
              <strong className="text-[#F3F5F7] font-mono tabular-nums">
                ${totalSpent.toLocaleString()}
              </strong>{' '}
              / ${totalBudget.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center gap-2 bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-1.5 min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-[#6B7280]" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Filter projects..."
              className="bg-transparent text-xs text-[#F3F5F7] placeholder:text-[#6B7280] focus:outline-none w-full"
            />
          </div>
        </div>
      </div>

      {/* Projects Grid */}
      {filteredProjects.length === 0 ? (
        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-12 text-center">
          <p className="text-sm font-semibold text-[#F3F5F7]">No matching projects found</p>
          <p className="text-xs text-[#9CA3AF] mt-1 mb-4">
            Try clearing your health filter or launch a new company initiative.
          </p>
          <button
            type="button"
            onClick={() => {
              setHealthFilter('All');
              setSearch('');
            }}
            className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#00D26A]/15 text-[#34D399] hover:bg-[#00D26A]/25"
          >
            Clear Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filteredProjects.map((project) => {
            const progress = getProjectProgress(project);
            const projectTasks = tasks.filter((t) => t.projectId === project.id);
            const doneTasks = projectTasks.filter((t) => t.status === 'completed').length;
            const lead = employees.find((e) => e.id === project.leadId);
            const members = project.memberIds
              .map((id) => employees.find((e) => e.id === id))
              .filter(Boolean);
            const doneMilestones = project.milestones.filter((m) => m.completed).length;
            const hStyle = HEALTH_STYLE[project.health];
            const StatusIcon = hStyle.Icon;

            return (
              <div
                key={project.id}
                className="bg-[#14171B] border border-[#232933] hover:border-[#00D26A]/45 rounded-2xl p-5 flex flex-col justify-between transition-colors"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <button
                      type="button"
                      onClick={() => setSelectedProjectId(project.id)}
                      className="flex items-center gap-3 text-left min-w-0 group"
                    >
                      <ProjectIcon iconKey={project.iconKey} />
                      <div className="min-w-0">
                        <h3 className="font-display text-[15px] font-bold text-[#F3F5F7] group-hover:text-[#34D399] truncate transition-colors">
                          {project.name}
                        </h3>
                        <p className="text-xs text-[#9CA3AF] truncate">{project.clientOrDept}</p>
                      </div>
                    </button>

                    <span
                      className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg border text-[11px] font-semibold shrink-0 ${hStyle.badge}`}
                    >
                      <StatusIcon className="w-3 h-3" />
                      <span>{project.health}</span>
                    </span>
                  </div>

                  <p className="text-xs text-[#D1D5DB] leading-relaxed line-clamp-2 mb-4">
                    {project.description}
                  </p>

                  <div className="mb-4">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="font-medium text-[#9CA3AF]">
                        Task Progress ({doneTasks}/{projectTasks.length})
                      </span>
                      <span className="font-mono font-semibold text-[#F3F5F7] tabular-nums">
                        {progress}%
                      </span>
                    </div>
                    <div className="w-full h-2 bg-[#1F242C] rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${hStyle.bar}`}
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-[#9CA3AF] py-2.5 border-t border-[#1F242C]">
                    <span className="inline-flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#6B7280]" />
                      <span className="tabular-nums">Due {project.dueDate}</span>
                    </span>
                    <span className="tabular-nums">
                      {doneMilestones}/{project.milestones.length} milestones
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-[#1F242C]">
                  <div className="flex items-center -space-x-2">
                    {members.slice(0, 4).map(
                      (emp) =>
                        emp && (
                          <button
                            key={emp.id}
                            type="button"
                            onClick={() => setSelectedEmployeeId(emp.id)}
                            title={`${emp.name} (${emp.roleTitle})`}
                            className="hover:z-10 transition-transform hover:scale-105"
                          >
                            <Avatar employee={emp} size="sm" />
                          </button>
                        )
                    )}
                    {lead && (
                      <span className="pl-3 text-[11px] text-[#9CA3AF] truncate max-w-[110px]">
                        Lead: {lead.name.split(' ')[0]}
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => setSelectedProjectId(project.id)}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold text-[#34D399] bg-[#00D26A]/12 hover:bg-[#00D26A]/20 border border-[#00D26A]/25 transition-colors whitespace-nowrap shrink-0"
                  >
                    Manage
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
