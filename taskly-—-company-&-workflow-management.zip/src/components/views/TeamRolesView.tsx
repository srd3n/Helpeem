import React, { useMemo, useState } from 'react';
import {
  Briefcase,
  Check,
  Mail,
  MapPin,
  Search,
  Shield,
  UserPlus,
  Users,
} from 'lucide-react';
import { PERMISSION_LABELS } from '../../data/initialData';
import { useCompany } from '../../store/CompanyContext';
import { AccessLevel, Department, PermissionKey } from '../../types';
import { Avatar } from '../Avatar';

interface TeamRolesViewProps {
  onOpenAddEmployee: () => void;
}

const DEPARTMENTS: ('All' | Department)[] = [
  'All',
  'Product',
  'Engineering',
  'Design',
  'Marketing',
  'Quality Assurance',
  'Operations',
];

const PERMISSION_KEYS = Object.keys(PERMISSION_LABELS) as PermissionKey[];

export const TeamRolesView: React.FC<TeamRolesViewProps> = ({ onOpenAddEmployee }) => {
  const { employees, tasks, projects, setSelectedEmployeeId, updateEmployee } = useCompany();

  const [tab, setTab] = useState<'directory' | 'roles'>('directory');
  const [deptFilter, setDeptFilter] = useState<'All' | Department>('All');
  const [search, setSearch] = useState('');

  const filteredEmployees = useMemo(() => {
    const q = search.trim().toLowerCase();
    return employees.filter((e) => {
      if (deptFilter !== 'All' && e.department !== deptFilter) return false;
      if (!q) return true;
      return (
        e.name.toLowerCase().includes(q) ||
        e.roleTitle.toLowerCase().includes(q) ||
        e.department.toLowerCase().includes(q) ||
        e.skills.some((s) => s.toLowerCase().includes(q))
      );
    });
  }, [employees, deptFilter, search]);

  const avgUtilization = useMemo(() => {
    if (employees.length === 0) return 0;
    const totalAlloc = employees.reduce((a, e) => a + e.allocatedHours, 0);
    const totalCap = employees.reduce((a, e) => a + e.weeklyCapacityHours, 0);
    return totalCap > 0 ? Math.round((totalAlloc / totalCap) * 100) : 0;
  }, [employees]);

  const togglePermission = (empId: string, perm: PermissionKey, current: PermissionKey[]) => {
    const next = current.includes(perm)
      ? current.filter((p) => p !== perm)
      : [...current, perm];
    updateEmployee(empId, { permissions: next });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#F3F5F7] tracking-tight">
            Team, Roles &amp; Details
          </h1>
          <p className="text-sm text-[#9CA3AF] mt-0.5">
            Manage employee profiles, organizational roles, permissions, capacity, and assigned tasks.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenAddEmployee}
          className="px-4 py-2.5 rounded-xl text-xs font-bold bg-[#00D26A] hover:bg-[#10E077] text-[#051B0E] inline-flex items-center gap-2 transition-colors self-start sm:self-auto whitespace-nowrap shrink-0"
        >
          <UserPlus className="w-4 h-4" />
          Add Employee
        </button>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-4 flex items-center gap-3.5">
          <span className="w-11 h-11 rounded-xl bg-[#00D26A]/12 text-[#00D26A] border border-[#00D26A]/20 inline-flex items-center justify-center shrink-0">
            <Users className="w-5 h-5" />
          </span>
          <div>
            <div className="text-xs text-[#9CA3AF]">Total Workforce</div>
            <div className="font-display text-xl font-bold text-[#F3F5F7] tabular-nums">
              {employees.length} Employees
            </div>
          </div>
        </div>

        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-4 flex items-center gap-3.5">
          <span className="w-11 h-11 rounded-xl bg-[#D9A05B]/12 text-[#E5B87A] border border-[#D9A05B]/20 inline-flex items-center justify-center shrink-0">
            <Shield className="w-5 h-5" />
          </span>
          <div>
            <div className="text-xs text-[#9CA3AF]">Role Tiers</div>
            <div className="font-display text-xl font-bold text-[#F3F5F7] tabular-nums">
              {employees.filter((e) => e.accessLevel === 'Admin').length} Admin ·{' '}
              {employees.filter((e) => e.accessLevel === 'Manager').length} Managers
            </div>
          </div>
        </div>

        <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-4 flex items-center gap-3.5">
          <span className="w-11 h-11 rounded-xl bg-sky-500/12 text-sky-400 border border-sky-500/20 inline-flex items-center justify-center shrink-0">
            <Briefcase className="w-5 h-5" />
          </span>
          <div>
            <div className="text-xs text-[#9CA3AF]">Weekly Capacity Used</div>
            <div className="font-display text-xl font-bold text-[#F3F5F7] tabular-nums">
              {avgUtilization}% Average
            </div>
          </div>
        </div>
      </div>

      {/* View Switcher & Department Filter */}
      <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="inline-flex p-1 bg-[#181C22] border border-[#252B35] rounded-xl">
            <button
              type="button"
              onClick={() => setTab('directory')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                tab === 'directory'
                  ? 'bg-[#232933] text-[#F3F5F7] font-semibold'
                  : 'text-[#9CA3AF]'
              }`}
            >
              Employee Directory
            </button>
            <button
              type="button"
              onClick={() => setTab('roles')}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                tab === 'roles'
                  ? 'bg-[#232933] text-[#F3F5F7] font-semibold'
                  : 'text-[#9CA3AF]'
              }`}
            >
              Roles &amp; Permissions Matrix
            </button>
          </div>

          <div className="flex items-center gap-1 flex-wrap">
            {DEPARTMENTS.map((dept) => (
              <button
                key={dept}
                type="button"
                onClick={() => setDeptFilter(dept)}
                className={`px-2.5 py-1.5 rounded-xl text-xs font-medium transition-colors whitespace-nowrap ${
                  deptFilter === dept
                    ? 'bg-[#00D26A]/15 text-[#34D399] font-semibold'
                    : 'text-[#9CA3AF] hover:bg-[#191D24]'
                }`}
              >
                {dept}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-1.5 min-w-[220px]">
          <Search className="w-3.5 h-3.5 text-[#6B7280]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, role, or skill..."
            className="bg-transparent text-xs text-[#F3F5F7] placeholder:text-[#6B7280] focus:outline-none w-full"
          />
        </div>
      </div>

      {tab === 'directory' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filteredEmployees.map((emp) => {
            const empTasks = tasks.filter((t) => t.assigneeId === emp.id);
            const openCount = empTasks.filter((t) => t.status !== 'completed').length;
            const doneCount = empTasks.filter((t) => t.status === 'completed').length;
            const empProjects = projects.filter(
              (p) => p.leadId === emp.id || p.memberIds.includes(emp.id)
            );
            const capacityPct = Math.min(
              100,
              Math.round((emp.allocatedHours / Math.max(1, emp.weeklyCapacityHours)) * 100)
            );

            return (
              <div
                key={emp.id}
                className="bg-[#14171B] border border-[#232933] hover:border-[#00D26A]/45 rounded-2xl p-5 flex flex-col justify-between transition-colors"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <button
                      type="button"
                      onClick={() => setSelectedEmployeeId(emp.id)}
                      className="flex items-center gap-3 text-left min-w-0 group"
                    >
                      <Avatar employee={emp} size="lg" />
                      <div className="min-w-0">
                        <h3 className="font-display text-[15px] font-bold text-[#F3F5F7] group-hover:text-[#34D399] truncate">
                          {emp.name}
                        </h3>
                        <p className="text-xs font-medium text-[#D1D5DB] truncate">
                          {emp.roleTitle}
                        </p>
                        <p className="text-[11px] text-[#9CA3AF] mt-0.5">
                          {emp.department} · {emp.accessLevel}
                        </p>
                      </div>
                    </button>

                    <span className="text-[11px] font-semibold text-[#34D399] shrink-0">
                      {emp.availability}
                    </span>
                  </div>

                  <div className="space-y-1 text-xs text-[#9CA3AF] mb-4">
                    <div className="flex items-center gap-2 truncate">
                      <Mail className="w-3.5 h-3.5 text-[#6B7280] shrink-0" />
                      <span className="truncate">{emp.email}</span>
                    </div>
                    <div className="flex items-center gap-2 truncate">
                      <MapPin className="w-3.5 h-3.5 text-[#6B7280] shrink-0" />
                      <span>{emp.location}</span>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="text-[#9CA3AF]">Weekly Workload</span>
                      <span className="font-mono font-semibold text-[#F3F5F7] tabular-nums">
                        {emp.allocatedHours}/{emp.weeklyCapacityHours}h ({capacityPct}%)
                      </span>
                    </div>
                    <div className="w-full h-2 bg-[#1F242C] rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-300"
                        style={{
                          width: `${capacityPct}%`,
                          background: capacityPct > 88 ? '#D9A05B' : '#00D26A',
                        }}
                      />
                    </div>
                  </div>

                  <p className="text-[11px] text-[#9CA3AF] truncate mb-4">
                    {emp.skills.join(' · ')}
                  </p>
                </div>

                <div className="pt-3 border-t border-[#1F242C] flex items-center justify-between gap-2">
                  <div className="text-xs text-[#9CA3AF] tabular-nums">
                    <strong className="text-[#F3F5F7]">{openCount}</strong> open ·{' '}
                    <strong className="text-[#34D399]">{doneCount}</strong> done ·{' '}
                    {empProjects.length} projects
                  </div>

                  <button
                    type="button"
                    onClick={() => setSelectedEmployeeId(emp.id)}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold text-[#34D399] bg-[#00D26A]/12 hover:bg-[#00D26A]/20 border border-[#00D26A]/25 transition-colors whitespace-nowrap shrink-0"
                  >
                    Details &amp; Tasks
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-[#14171B] border border-[#232933] rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#232933] bg-[#181C22] text-[11px] font-semibold text-[#9CA3AF]">
                  <th className="py-3.5 px-4">Employee</th>
                  <th className="py-3.5 px-3">Role Title</th>
                  <th className="py-3.5 px-3">Access Tier</th>
                  {PERMISSION_KEYS.map((key) => (
                    <th key={key} className="py-3.5 px-3 text-center whitespace-nowrap">
                      {PERMISSION_LABELS[key].label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1F242C] text-xs">
                {filteredEmployees.map((emp) => (
                  <tr key={emp.id} className="hover:bg-[#191E25] transition-colors">
                    <td className="py-3 px-4 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => setSelectedEmployeeId(emp.id)}
                        className="flex items-center gap-2.5 text-left hover:text-[#34D399]"
                      >
                        <Avatar employee={emp} size="sm" />
                        <div>
                          <div className="font-semibold text-[#F3F5F7]">{emp.name}</div>
                          <div className="text-[11px] text-[#9CA3AF]">{emp.department}</div>
                        </div>
                      </button>
                    </td>

                    <td className="py-3 px-3 whitespace-nowrap font-medium text-[#D1D5DB]">
                      {emp.roleTitle}
                    </td>

                    <td className="py-3 px-3 whitespace-nowrap">
                      <select
                        value={emp.accessLevel}
                        onChange={(e) =>
                          updateEmployee(emp.id, {
                            accessLevel: e.target.value as AccessLevel,
                          })
                        }
                        aria-label={`Access tier for ${emp.name}`}
                        className="bg-[#181C22] border border-[#2A313D] rounded-lg px-2 py-1 text-xs font-medium text-[#F3F5F7] focus:outline-none focus:ring-2 focus:ring-[#00D26A]"
                      >
                        <option value="Admin" className="bg-[#15191F]">
                          Admin
                        </option>
                        <option value="Manager" className="bg-[#15191F]">
                          Manager
                        </option>
                        <option value="Member" className="bg-[#15191F]">
                          Member
                        </option>
                        <option value="Viewer" className="bg-[#15191F]">
                          Viewer
                        </option>
                      </select>
                    </td>

                    {PERMISSION_KEYS.map((perm) => {
                      const enabled = emp.permissions.includes(perm);
                      return (
                        <td key={perm} className="py-3 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => togglePermission(emp.id, perm, emp.permissions)}
                            aria-label={`${PERMISSION_LABELS[perm].label} for ${emp.name}`}
                            className={`w-6 h-6 rounded-lg inline-flex items-center justify-center border transition-colors ${
                              enabled
                                ? 'bg-[#00D26A] border-[#00D26A] text-[#051B0E]'
                                : 'bg-[#181C22] border-[#2E3643] text-transparent hover:border-[#00D26A]'
                            }`}
                          >
                            <Check className="w-3.5 h-3.5 stroke-[2.6]" />
                          </button>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
