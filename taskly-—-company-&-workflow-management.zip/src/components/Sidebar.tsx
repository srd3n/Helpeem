import React from 'react';
import {
  BarChart3,
  CalendarDays,
  CheckSquare,
  FolderKanban,
  Home,
  Kanban,
  Plus,
  Users,
  X,
} from 'lucide-react';
import { useCompany } from '../store/CompanyContext';
import { NavSection } from '../types';

interface SidebarProps {
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onOpenNewProject: () => void;
}

const NAV_ITEMS: { id: NavSection; label: string; Icon: React.FC<{ className?: string }> }[] = [
  { id: 'dashboard', label: 'Dashboard', Icon: Home },
  { id: 'tasks', label: 'My Tasks', Icon: CheckSquare },
  { id: 'projects', label: 'Projects', Icon: FolderKanban },
  { id: 'kanban', label: 'Kanban', Icon: Kanban },
  { id: 'team', label: 'Team & Roles', Icon: Users },
  { id: 'calendar', label: 'Calendar', Icon: CalendarDays },
  { id: 'reports', label: 'Reports', Icon: BarChart3 },
];

export const Sidebar: React.FC<SidebarProps> = ({
  mobileOpen,
  onCloseMobile,
  onOpenNewProject,
}) => {
  const { activeSection, setActiveSection, projects, tasks } = useCompany();

  const completedTasks = tasks.filter((t) => t.status === 'completed').length;
  const totalTasks = tasks.length || 1;
  const completionPct = Math.round((completedTasks / totalTasks) * 100);

  const handleSelect = (id: NavSection) => {
    setActiveSection(id);
    onCloseMobile();
  };

  const navContent = (
    <div className="flex flex-col h-full bg-[#101317] border-r border-[#1F242C] w-[240px] px-4 py-5 select-none">
      {/* Brand Header — FILLUPRO geometric emblem & wordmark */}
      <div className="flex items-center justify-between px-2 mb-8">
        <button
          type="button"
          onClick={() => handleSelect('dashboard')}
          className="flex items-center gap-3 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00D26A] rounded-lg"
        >
          <svg
            width="28"
            height="30"
            viewBox="0 0 28 30"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
            className="shrink-0 drop-shadow-[0_0_10px_rgba(0,210,106,0.35)]"
          >
            <rect x="1" y="1" width="26" height="6.5" rx="2.2" fill="#00D26A" />
            <rect x="1" y="10.2" width="16.5" height="6.2" rx="2.2" fill="#00D26A" />
            <rect x="1" y="19.1" width="7" height="9.9" rx="2.2" fill="#00D26A" />
          </svg>
          <span className="font-display text-[19px] font-extrabold tracking-[0.06em] text-[#F3F5F7] whitespace-nowrap shrink-0">
            FILLUPRO
          </span>
        </button>

        <button
          type="button"
          onClick={onCloseMobile}
          className="lg:hidden p-1.5 text-[#9CA3AF] hover:text-white rounded-lg"
          aria-label="Close navigation menu"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Primary Navigation */}
      <nav aria-label="Primary Sidebar" className="flex-1 space-y-1 overflow-y-auto pr-1">
        {NAV_ITEMS.map(({ id, label, Icon }) => {
          const isActive = activeSection === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => handleSelect(id)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-[14px] font-medium transition-all duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#00D26A] ${
                isActive
                  ? 'bg-[#00D26A]/12 text-[#34D399] font-semibold border border-[#00D26A]/25'
                  : 'text-[#9CA3AF] hover:text-[#F3F5F7] hover:bg-[#171B21] border border-transparent'
              }`}
            >
              <Icon
                className={`w-[18px] h-[18px] shrink-0 ${
                  isActive ? 'text-[#00D26A]' : 'text-[#6B7280]'
                }`}
              />
              <span className="truncate">{label}</span>
            </button>
          );
        })}
      </nav>

      {/* Bottom Architectural Sprint Goal Card */}
      <div className="mt-5 rounded-2xl p-4 bg-[#15191F] border border-[#232933] relative overflow-hidden">
        <div
          aria-hidden="true"
          className="absolute -right-6 -top-6 w-24 h-24 rounded-full bg-[#00D26A]/15 blur-xl pointer-events-none"
        />
        <div className="relative z-10">
          <div className="flex items-center justify-between text-xs font-medium text-[#9CA3AF] mb-1">
            <span>Q4 Company Goal</span>
            <span className="tabular-nums font-mono font-semibold text-[#34D399]">
              {completionPct}%
            </span>
          </div>
          <p className="text-[13px] font-semibold text-[#F3F5F7] leading-snug mb-3">
            {projects.length} active projects · {completedTasks}/{totalTasks} tasks done
          </p>
          <div className="w-full h-1.5 bg-[#232933] rounded-full overflow-hidden mb-3.5">
            <div
              className="h-full bg-[#00D26A] rounded-full transition-all duration-300"
              style={{ width: `${completionPct}%` }}
            />
          </div>
          <button
            type="button"
            onClick={() => {
              onOpenNewProject();
              onCloseMobile();
            }}
            className="w-full py-2 px-3 bg-[#00D26A] hover:bg-[#10E077] text-[#051B0E] rounded-xl text-xs font-bold inline-flex items-center justify-center gap-1.5 transition-colors active:scale-[0.99] whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            New Project
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden lg:block shrink-0">{navContent}</aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/65 backdrop-blur-[1px]"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative z-10 h-full">{navContent}</div>
        </div>
      )}
    </>
  );
};
