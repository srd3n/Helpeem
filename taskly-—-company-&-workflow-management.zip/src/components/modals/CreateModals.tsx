import React, { useState } from 'react';
import { X } from 'lucide-react';
import { useCompany } from '../../store/CompanyContext';
import {
  AccessLevel,
  Department,
  PermissionKey,
  Project,
  ProjectHealth,
  TaskPriority,
} from '../../types';

export const NewProjectModal: React.FC<{ open: boolean; onClose: () => void }> = ({
  open,
  onClose,
}) => {
  const { employees, addProject, setSelectedProjectId } = useCompany();
  const [name, setName] = useState('');
  const [clientOrDept, setClientOrDept] = useState('Core Product');
  const [description, setDescription] = useState('');
  const [leadId, setLeadId] = useState(employees[0]?.id ?? 'emp-sarah');
  const [health, setHealth] = useState<ProjectHealth>('On Track');
  const [dueDate, setDueDate] = useState('2026-12-18');
  const [budget, setBudget] = useState(40000);
  const [iconKey, setIconKey] = useState<Project['iconKey']>('sparkles');

  if (!open) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const created = addProject({
      name: name.trim(),
      clientOrDept: clientOrDept.trim() || 'Internal',
      description:
        description.trim() ||
        'Cross-functional company initiative tracked through milestones and sprint tasks.',
      leadId,
      memberIds: [leadId],
      health,
      status: 'Active',
      startDate: '2026-11-20',
      dueDate,
      budget: Number(budget) || 25000,
      spent: 0,
      iconKey,
      accentColor: '#00D26A',
      milestones: [
        { id: `ms-${Date.now()}`, title: 'Kickoff & Scope Sign-Off', dueDate, completed: false },
      ],
    });
    setName('');
    setDescription('');
    onClose();
    setSelectedProjectId(created.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/70" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-label="Create new project"
        className="relative z-10 w-full max-w-lg bg-[#14171B] border border-[#262C36] rounded-2xl shadow-2xl p-6 text-[#F3F5F7]"
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-lg font-bold text-[#F3F5F7]">Create Company Project</h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-[#9CA3AF] hover:bg-[#1F242C]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Project Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Enterprise Portal v2"
              className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3.5 py-2 text-sm text-[#F3F5F7] placeholder:text-[#6B7280] focus:outline-none focus:border-[#00D26A]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">
                Department / Client
              </label>
              <input
                type="text"
                value={clientOrDept}
                onChange={(e) => setClientOrDept(e.target.value)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">
                Project Lead
              </label>
              <select
                value={leadId}
                onChange={(e) => setLeadId(e.target.value)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
              >
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">
                Target Due Date
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs font-mono text-[#F3F5F7]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Budget ($)</label>
              <input
                type="number"
                min={1000}
                step={500}
                value={budget}
                onChange={(e) => setBudget(Number(e.target.value))}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs font-mono text-[#F3F5F7]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">
                Initial Health
              </label>
              <select
                value={health}
                onChange={(e) => setHealth(e.target.value as ProjectHealth)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
              >
                <option value="On Track">On Track</option>
                <option value="At Risk">At Risk</option>
                <option value="Delayed">Delayed</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Icon</label>
              <select
                value={iconKey}
                onChange={(e) => setIconKey(e.target.value as Project['iconKey'])}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
              >
                <option value="sparkles">Sparkles</option>
                <option value="globe">Web / Globe</option>
                <option value="smartphone">Mobile</option>
                <option value="layers">Platform / CRM</option>
                <option value="megaphone">Marketing</option>
                <option value="cloud">Cloud</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Outline key objectives and deliverables..."
              className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7] placeholder:text-[#6B7280] focus:outline-none focus:border-[#00D26A]"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-[#9CA3AF] hover:bg-[#1F242C]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl text-xs font-bold bg-[#00D26A] hover:bg-[#10E077] text-[#051B0E]"
            >
              Create Project
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export const NewTaskModal: React.FC<{
  open: boolean;
  onClose: () => void;
  defaultProjectId?: string;
  defaultAssigneeId?: string;
  defaultDueDate?: string;
}> = ({ open, onClose, defaultProjectId, defaultAssigneeId, defaultDueDate }) => {
  const { projects, employees, addTask } = useCompany();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [projectId, setProjectId] = useState(defaultProjectId ?? projects[0]?.id ?? 'proj-web');
  const [assigneeId, setAssigneeId] = useState(
    defaultAssigneeId ?? employees[0]?.id ?? 'emp-sarah'
  );
  const [priority, setPriority] = useState<TaskPriority>('High');
  const [dueDate, setDueDate] = useState(defaultDueDate ?? '2026-11-24');
  const [estimatedHours, setEstimatedHours] = useState(8);

  if (!open) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    addTask({
      title: title.trim(),
      description: description.trim() || 'Assigned via FILLUPRO company operations dashboard.',
      projectId: defaultProjectId ?? projectId,
      assigneeId: defaultAssigneeId ?? assigneeId,
      status: 'todo',
      priority,
      dueDate,
      estimatedHours: Number(estimatedHours) || 4,
      loggedHours: 0,
      subtasks: [],
    });
    setTitle('');
    setDescription('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/70" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-label="Create new task"
        className="relative z-10 w-full max-w-lg bg-[#14171B] border border-[#262C36] rounded-2xl shadow-2xl p-6 text-[#F3F5F7]"
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-lg font-bold text-[#F3F5F7]">Create &amp; Assign Task</h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-[#9CA3AF] hover:bg-[#1F242C]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Task Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Implement role audit logging"
              className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3.5 py-2 text-sm text-[#F3F5F7] placeholder:text-[#6B7280] focus:outline-none focus:border-[#00D26A]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Project</label>
              <select
                value={defaultProjectId ?? projectId}
                onChange={(e) => setProjectId(e.target.value)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
              >
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">
                Assign to Employee
              </label>
              <select
                value={defaultAssigneeId ?? assigneeId}
                onChange={(e) => setAssigneeId(e.target.value)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
              >
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.name} ({emp.roleTitle})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as TaskPriority)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Urgent">Urgent</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Due Date</label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs font-mono text-[#F3F5F7]"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">
                Estimated Hours
              </label>
              <input
                type="number"
                min={1}
                max={100}
                value={estimatedHours}
                onChange={(e) => setEstimatedHours(Number(e.target.value))}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs font-mono text-[#F3F5F7]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Details</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Acceptance criteria and notes..."
              className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7] placeholder:text-[#6B7280] focus:outline-none focus:border-[#00D26A]"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-[#9CA3AF] hover:bg-[#1F242C]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl text-xs font-bold bg-[#00D26A] hover:bg-[#10E077] text-[#051B0E]"
            >
              Create Task
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export const AddEmployeeModal: React.FC<{ open: boolean; onClose: () => void }> = ({
  open,
  onClose,
}) => {
  const { addEmployee, setSelectedEmployeeId } = useCompany();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [roleTitle, setRoleTitle] = useState('Product Engineer');
  const [department, setDepartment] = useState<Department>('Engineering');
  const [accessLevel, setAccessLevel] = useState<AccessLevel>('Member');
  const [location, setLocation] = useState('Remote, US');
  const [skillsText, setSkillsText] = useState('TypeScript, React, Product Ops');

  if (!open) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const initials = name
      .trim()
      .split(' ')
      .map((p) => p[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();

    const defaultPerms: PermissionKey[] =
      accessLevel === 'Admin'
        ? [
            'manage_projects',
            'assign_tasks',
            'manage_roles',
            'view_reports',
            'approve_deliverables',
            'manage_budgets',
          ]
        : accessLevel === 'Manager'
        ? ['manage_projects', 'assign_tasks', 'view_reports', 'approve_deliverables']
        : ['assign_tasks', 'view_reports'];

    const created = addEmployee({
      name: name.trim(),
      email:
        email.trim() || `${name.trim().toLowerCase().replace(/\s+/g, '.')}@fillupro.com`,
      phone: '+1 (415) 555-0194',
      location: location.trim() || 'Remote',
      initials,
      department,
      roleTitle: roleTitle.trim() || 'Team Specialist',
      accessLevel,
      permissions: defaultPerms,
      weeklyCapacityHours: 40,
      allocatedHours: 16,
      availability: 'Active',
      skills: skillsText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean),
      joinedDate: '2026-11-20',
      bio: `${roleTitle.trim()} supporting ${department} initiatives across FILLUPRO operations.`,
    });

    setName('');
    setEmail('');
    onClose();
    setSelectedEmployeeId(created.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/70" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-label="Add team member"
        className="relative z-10 w-full max-w-lg bg-[#14171B] border border-[#262C36] rounded-2xl shadow-2xl p-6 text-[#F3F5F7]"
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-lg font-bold text-[#F3F5F7]">
            Add Employee &amp; Assign Role
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-[#9CA3AF] hover:bg-[#1F242C]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Clara Vance"
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7] placeholder:text-[#6B7280]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Work Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="clara.vance@fillupro.com"
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7] placeholder:text-[#6B7280]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Role Title</label>
              <input
                type="text"
                required
                value={roleTitle}
                onChange={(e) => setRoleTitle(e.target.value)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Department</label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value as Department)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
              >
                <option value="Engineering">Engineering</option>
                <option value="Product">Product</option>
                <option value="Design">Design</option>
                <option value="Marketing">Marketing</option>
                <option value="Quality Assurance">Quality Assurance</option>
                <option value="Operations">Operations</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">
                Access Level
              </label>
              <select
                value={accessLevel}
                onChange={(e) => setAccessLevel(e.target.value as AccessLevel)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
              >
                <option value="Admin">Admin</option>
                <option value="Manager">Manager</option>
                <option value="Member">Member</option>
                <option value="Viewer">Viewer</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">Location</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#D1D5DB] mb-1">
              Skills (comma-separated)
            </label>
            <input
              type="text"
              value={skillsText}
              onChange={(e) => setSkillsText(e.target.value)}
              className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-[#9CA3AF] hover:bg-[#1F242C]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl text-xs font-bold bg-[#00D26A] hover:bg-[#10E077] text-[#051B0E]"
            >
              Onboard Employee
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
