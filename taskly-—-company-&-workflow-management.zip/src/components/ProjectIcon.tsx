import React from 'react';
import { Cloud, Globe, Layers, Megaphone, Smartphone, Sparkles } from 'lucide-react';
import { Project } from '../types';

interface ProjectIconProps {
  iconKey: Project['iconKey'];
  size?: 'sm' | 'md';
}

const ICON_CONFIG: Record<
  Project['iconKey'],
  { Icon: React.FC<{ className?: string }>; boxClass: string }
> = {
  globe: {
    Icon: Globe,
    boxClass: 'bg-[#00D26A]/12 text-[#34D399] border-[#00D26A]/25',
  },
  smartphone: {
    Icon: Smartphone,
    boxClass: 'bg-[#D9A05B]/12 text-[#E5B87A] border-[#D9A05B]/25',
  },
  layers: {
    Icon: Layers,
    boxClass: 'bg-sky-500/12 text-sky-400 border-sky-500/25',
  },
  megaphone: {
    Icon: Megaphone,
    boxClass: 'bg-emerald-500/12 text-emerald-300 border-emerald-500/25',
  },
  cloud: {
    Icon: Cloud,
    boxClass: 'bg-teal-500/12 text-teal-300 border-teal-500/25',
  },
  sparkles: {
    Icon: Sparkles,
    boxClass: 'bg-amber-500/12 text-amber-300 border-amber-500/25',
  },
};

export const ProjectIcon: React.FC<ProjectIconProps> = ({ iconKey, size = 'md' }) => {
  const { Icon, boxClass } = ICON_CONFIG[iconKey] ?? ICON_CONFIG.globe;
  const dim = size === 'sm' ? 'w-8 h-8 rounded-lg' : 'w-9 h-9 rounded-xl';
  const iconDim = size === 'sm' ? 'w-4 h-4' : 'w-[18px] h-[18px]';

  return (
    <span className={`${dim} ${boxClass} border inline-flex items-center justify-center shrink-0`}>
      <Icon className={iconDim} />
    </span>
  );
};
