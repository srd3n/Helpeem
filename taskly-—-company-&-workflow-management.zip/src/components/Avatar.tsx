import React, { useState } from 'react';
import { Employee } from '../types';

interface AvatarProps {
  employee?: Pick<Employee, 'name' | 'avatarUrl' | 'initials'>;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const SIZE_CLASSES: Record<NonNullable<AvatarProps['size']>, string> = {
  xs: 'w-6 h-6 text-[10px]',
  sm: 'w-8 h-8 text-xs',
  md: 'w-9 h-9 text-xs',
  lg: 'w-11 h-11 text-sm',
  xl: 'w-14 h-14 text-base',
};

const BG_PALETTE = [
  'bg-[#00D26A]/15 text-[#34D399]',
  'bg-[#D9A05B]/15 text-[#E5B87A]',
  'bg-sky-500/15 text-sky-300',
  'bg-emerald-500/15 text-emerald-300',
  'bg-amber-500/15 text-amber-300',
];

export const Avatar: React.FC<AvatarProps> = ({ employee, size = 'md', className = '' }) => {
  const [imgError, setImgError] = useState(false);

  const name = employee?.name ?? 'Team Member';
  const initials =
    employee?.initials ??
    name
      .split(' ')
      .map((p) => p[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();

  const colorIndex =
    name.split('').reduce((acc, ch) => acc + ch.charCodeAt(0), 0) % BG_PALETTE.length;

  const sizeClass = SIZE_CLASSES[size];

  if (employee?.avatarUrl && !imgError) {
    return (
      <img
        src={employee.avatarUrl}
        alt={name}
        referrerPolicy="no-referrer"
        onError={() => setImgError(true)}
        className={`${sizeClass} rounded-full object-cover shrink-0 ring-2 ring-[#14171B] ${className}`}
      />
    );
  }

  return (
    <span
      aria-label={name}
      className={`${sizeClass} ${BG_PALETTE[colorIndex]} rounded-full inline-flex items-center justify-center font-semibold shrink-0 ring-2 ring-[#14171B] select-none ${className}`}
    >
      {initials}
    </span>
  );
};
