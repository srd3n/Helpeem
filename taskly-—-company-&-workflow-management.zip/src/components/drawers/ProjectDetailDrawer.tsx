import React, { useState } from 'react';
import { Check, CheckSquare, Plus, Square, X } from 'lucide-react';
import { useCompany } from '../../store/CompanyContext';
import { ProjectHealth, TaskStatus } from '../../types';
import { Avatar } from '../Avatar';
import { ProjectIcon } from '../ProjectIcon';

interface ProjectDetailDrawerProps {
  onOpenNewTaskForProject: (projectId: string) => void;
}

export const ProjectDetailDrawer: React.FC<ProjectDetailDrawerProps> = ({
  onOpenNewTaskForProject,
}) => {
  const {
    projects,
    tasks,
    employees,
    selectedProjectId,
    setSelectedProjectId,
    setSelectedEmployeeId,
    setSelectedTaskId,
    getProjectProgress,
    updateProject,
    toggleMilestone,
    moveTaskStatus,
  } = useCompany();

  const [newMilestoneTitle, setNewMilestoneTitle] = useState('');

  const project = projects.find((p) => p.id === selectedProjectId);
  if (!project) return null;

  const projectTasks = tasks.filter((t) => t.projectId === project.id);
  const progress = getProjectProgress(project);
  const lead = employees.find((e) => e.id === project.leadId);

  const handleAddMilestone = (e: React.FormEvent) => {
    e.preventDefault();
    const title = newMilestoneTitle.trim();
    if (!title) return;
    updateProject(project.id, {
      milestones: [
        ...project.milestones,
        {
          id: `ms-${Date.now()}`,
          title,
          dueDate: project.dueDate,
          completed: false,
        },
      ],
    });
    setNewMilestoneTitle('');
  };

  const toggleProjectMember = (empId: string) => {
    const exists = project.memberIds.includes(empId);
    const next = exists
      ? project.memberIds.filter((id) => id !== empId)
      : [...project.memberIds, empId];
    updateProject(project.id, { memberIds: next });
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div
        className="fixed inset-0 bg-black/65 backdrop-blur-[1px]"
        onClick={() => setSelectedProjectId(null)}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-label={`${project.name} details`}
        className="relative z-10 w-full max-w-xl bg-[#14171B] h-full shadow-2xl border-l border-[#232933] flex flex-col text-[#F3F5F7]"
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-[#232933] flex items-start justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <ProjectIcon iconKey={project.iconKey} />
            <div className="min-w-0">
              <h2 className="font-display text-lg font-bold text-[#F3F5F7] truncate">
                {project.name}
              </h2>
              <p className="text-xs text-[#9CA3AF]">
                {project.clientOrDept} · Due {project.dueDate}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setSelectedProjectId(null)}
            className="p-2 rounded-xl text-[#9CA3AF] hover:bg-[#1F242C] hover:text-white"
            aria-label="Close project details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <p className="text-sm text-[#D1D5DB] leading-relaxed">{project.description}</p>

          {/* Progress & Health Controls */}
          <div className="bg-[#181C22] border border-[#252B35] rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div>
                <div className="text-xs font-medium text-[#9CA3AF]">Overall Completion</div>
                <div className="font-display text-2xl font-bold text-[#F3F5F7] tabular-nums">
                  {progress}%
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#9CA3AF] mb-1">
                  Delivery Health
                </label>
                <select
                  value={project.health}
                  onChange={(e) =>
                    updateProject(project.id, { health: e.target.value as ProjectHealth })
                  }
                  className="bg-[#14171B] border border-[#2A313D] rounded-xl px-3 py-1.5 text-xs font-semibold text-[#F3F5F7] focus:outline-none focus:ring-2 focus:ring-[#00D26A]"
                >
                  <option value="On Track">On Track</option>
                  <option value="At Risk">At Risk</option>
                  <option value="Delayed">Delayed</option>
                </select>
              </div>
            </div>

            <div className="w-full h-2.5 bg-[#111418] rounded-full overflow-hidden border border-[#232933]">
              <div
                className="h-full rounded-full transition-all duration-300 bg-[#00D26A]"
                style={{ width: `${progress}%` }}
              />
            </div>

            <div className="grid grid-cols-3 gap-3 pt-1 text-xs">
              <div>
                <span className="text-[#9CA3AF] block">Project Lead</span>
                <span className="font-semibold text-[#F3F5F7]">{lead?.name ?? 'Unassigned'}</span>
              </div>
              <div>
                <span className="text-[#9CA3AF] block">Budget Spent</span>
                <span className="font-mono font-semibold text-[#F3F5F7] tabular-nums">
                  ${project.spent.toLocaleString()}
                </span>
              </div>
              <div>
                <span className="text-[#9CA3AF] block">Total Budget</span>
                <span className="font-mono font-semibold text-[#F3F5F7] tabular-nums">
                  ${project.budget.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Assigned Team Members */}
          <div>
            <h3 className="font-display text-sm font-bold text-[#F3F5F7] mb-2.5">
              Project Team ({project.memberIds.length})
            </h3>
            <div className="flex flex-wrap gap-2">
              {employees.map((emp) => {
                const isMember = project.memberIds.includes(emp.id);
                return (
                  <button
                    key={emp.id}
                    type="button"
                    onClick={() => toggleProjectMember(emp.id)}
                    className={`inline-flex items-center gap-2 px-2.5 py-1.5 rounded-xl border text-xs transition-colors ${
                      isMember
                        ? 'bg-[#00D26A]/12 border-[#00D26A]/35 text-[#34D399] font-semibold'
                        : 'bg-[#181C22] border-[#252B35] text-[#9CA3AF] hover:border-[#374151]'
                    }`}
                  >
                    <Avatar employee={emp} size="xs" />
                    <span>{emp.name}</span>
                    {isMember && <Check className="w-3.5 h-3.5 text-[#00D26A]" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Milestones */}
          <div>
            <h3 className="font-display text-sm font-bold text-[#F3F5F7] mb-2.5">
              Milestones ({project.milestones.filter((m) => m.completed).length}/
              {project.milestones.length})
            </h3>
            <div className="space-y-2 mb-3">
              {project.milestones.map((ms) => (
                <button
                  key={ms.id}
                  type="button"
                  onClick={() => toggleMilestone(project.id, ms.id)}
                  className="w-full flex items-center justify-between gap-3 p-3 rounded-xl bg-[#181C22] border border-[#252B35] hover:border-[#00D26A]/40 text-left transition-colors"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {ms.completed ? (
                      <CheckSquare className="w-4 h-4 text-[#00D26A] shrink-0" />
                    ) : (
                      <Square className="w-4 h-4 text-[#6B7280] shrink-0" />
                    )}
                    <span
                      className={`text-xs font-medium truncate ${
                        ms.completed ? 'line-through text-[#6B7280]' : 'text-[#F3F5F7]'
                      }`}
                    >
                      {ms.title}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-[#9CA3AF] shrink-0">
                    {ms.dueDate}
                  </span>
                </button>
              ))}
            </div>

            <form onSubmit={handleAddMilestone} className="flex items-center gap-2">
              <input
                type="text"
                value={newMilestoneTitle}
                onChange={(e) => setNewMilestoneTitle(e.target.value)}
                placeholder="Add milestone title..."
                className="flex-1 bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7] placeholder:text-[#6B7280] focus:outline-none focus:border-[#00D26A]"
              />
              <button
                type="submit"
                className="px-3 py-2 rounded-xl text-xs font-semibold bg-[#00D26A]/15 text-[#34D399] hover:bg-[#00D26A]/25"
              >
                Add
              </button>
            </form>
          </div>

          {/* Linked Tasks */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <h3 className="font-display text-sm font-bold text-[#F3F5F7]">
                Project Tasks ({projectTasks.length})
              </h3>
              <button
                type="button"
                onClick={() => onOpenNewTaskForProject(project.id)}
                className="text-xs font-semibold text-[#34D399] hover:text-[#6EE7B7] inline-flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Task
              </button>
            </div>

            <div className="divide-y divide-[#1F242C] border border-[#232933] rounded-2xl overflow-hidden bg-[#181C22]">
              {projectTasks.length === 0 ? (
                <div className="p-4 text-xs text-[#6B7280] text-center">
                  No tasks assigned to this project yet.
                </div>
              ) : (
                projectTasks.map((t) => {
                  const assignee = employees.find((e) => e.id === t.assigneeId);
                  return (
                    <div
                      key={t.id}
                      className="p-3 flex items-center justify-between gap-3 hover:bg-[#1E232B]"
                    >
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedProjectId(null);
                          setSelectedTaskId(t.id);
                        }}
                        className="min-w-0 text-left flex-1"
                      >
                        <div className="text-xs font-semibold text-[#F3F5F7] truncate">
                          {t.title}
                        </div>
                        <div className="text-[11px] text-[#9CA3AF] flex items-center gap-2 mt-0.5">
                          <span className="font-mono text-[#34D399]">{t.code}</span>
                          <span>·</span>
                          <span
                            onClick={(e) => {
                              if (assignee) {
                                e.stopPropagation();
                                setSelectedProjectId(null);
                                setSelectedEmployeeId(assignee.id);
                              }
                            }}
                            className="hover:text-[#34D399]"
                          >
                            {assignee?.name ?? 'Unassigned'}
                          </span>
                        </div>
                      </button>

                      <select
                        value={t.status}
                        onChange={(e) => moveTaskStatus(t.id, e.target.value as TaskStatus)}
                        aria-label={`Status for ${t.title}`}
                        className="bg-[#14171B] border border-[#2A313D] rounded-lg px-2 py-1 text-[11px] font-medium text-[#F3F5F7]"
                      >
                        <option value="todo">To Do</option>
                        <option value="in_progress">In Progress</option>
                        <option value="in_review">In Review</option>
                        <option value="completed">Completed</option>
                      </select>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
