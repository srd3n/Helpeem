import React, { useState } from 'react';
import { Check, Mail, MapPin, Phone, Plus, Save, X } from 'lucide-react';
import { PERMISSION_LABELS } from '../../data/initialData';
import { useCompany } from '../../store/CompanyContext';
import { AccessLevel, Department, PermissionKey, TaskStatus } from '../../types';
import { Avatar } from '../Avatar';

interface EmployeeDetailDrawerProps {
  onOpenNewTaskForEmployee: (empId: string) => void;
}

const PERMISSION_KEYS = Object.keys(PERMISSION_LABELS) as PermissionKey[];

export const EmployeeDetailDrawer: React.FC<EmployeeDetailDrawerProps> = ({
  onOpenNewTaskForEmployee,
}) => {
  const {
    employees,
    projects,
    tasks,
    selectedEmployeeId,
    setSelectedEmployeeId,
    setSelectedProjectId,
    setSelectedTaskId,
    updateEmployee,
    moveTaskStatus,
  } = useCompany();

  const employee = employees.find((e) => e.id === selectedEmployeeId);
  const [editingRole, setEditingRole] = useState(false);
  const [roleDraft, setRoleDraft] = useState('');
  const [deptDraft, setDeptDraft] = useState<Department>('Engineering');
  const [accessDraft, setAccessDraft] = useState<AccessLevel>('Member');
  const [allocDraft, setAllocDraft] = useState(32);

  if (!employee) return null;

  const empTasks = tasks.filter((t) => t.assigneeId === employee.id);
  const empProjects = projects.filter(
    (p) => p.leadId === employee.id || p.memberIds.includes(employee.id)
  );
  const capacityPct = Math.min(
    100,
    Math.round((employee.allocatedHours / Math.max(1, employee.weeklyCapacityHours)) * 100)
  );

  const startEdit = () => {
    setRoleDraft(employee.roleTitle);
    setDeptDraft(employee.department);
    setAccessDraft(employee.accessLevel);
    setAllocDraft(employee.allocatedHours);
    setEditingRole(true);
  };

  const saveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    updateEmployee(employee.id, {
      roleTitle: roleDraft.trim() || employee.roleTitle,
      department: deptDraft,
      accessLevel: accessDraft,
      allocatedHours: Math.max(0, Math.min(60, Number(allocDraft) || 0)),
    });
    setEditingRole(false);
  };

  const togglePerm = (perm: PermissionKey) => {
    const next = employee.permissions.includes(perm)
      ? employee.permissions.filter((p) => p !== perm)
      : [...employee.permissions, perm];
    updateEmployee(employee.id, { permissions: next });
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div
        className="fixed inset-0 bg-black/65 backdrop-blur-[1px]"
        onClick={() => {
          setEditingRole(false);
          setSelectedEmployeeId(null);
        }}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-label={`${employee.name} profile and tasks`}
        className="relative z-10 w-full max-w-xl bg-[#14171B] h-full shadow-2xl border-l border-[#232933] flex flex-col text-[#F3F5F7]"
      >
        <div className="px-6 py-5 border-b border-[#232933] flex items-start justify-between gap-4">
          <div className="flex items-center gap-3.5 min-w-0">
            <Avatar employee={employee} size="xl" />
            <div className="min-w-0">
              <h2 className="font-display text-lg font-bold text-[#F3F5F7] truncate">
                {employee.name}
              </h2>
              <p className="text-xs font-semibold text-[#34D399] truncate">
                {employee.roleTitle} · {employee.department}
              </p>
              <p className="text-[11px] text-[#9CA3AF] mt-0.5">
                Access Level: {employee.accessLevel} · Joined {employee.joinedDate}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              setEditingRole(false);
              setSelectedEmployeeId(null);
            }}
            className="p-2 rounded-xl text-[#9CA3AF] hover:bg-[#1F242C] hover:text-white"
            aria-label="Close employee details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="bg-[#181C22] border border-[#252B35] rounded-2xl p-4 space-y-3">
            <p className="text-xs text-[#D1D5DB] leading-relaxed">{employee.bio}</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-[#232933] text-xs text-[#9CA3AF]">
              <span className="inline-flex items-center gap-2 truncate">
                <Mail className="w-3.5 h-3.5 text-[#6B7280] shrink-0" />
                <span className="truncate">{employee.email}</span>
              </span>
              <span className="inline-flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#6B7280] shrink-0" />
                <span className="tabular-nums">{employee.phone}</span>
              </span>
              <span className="inline-flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#6B7280] shrink-0" />
                <span>{employee.location}</span>
              </span>
              <span className="inline-flex items-center gap-2">
                <span className="text-[#9CA3AF]">Availability:</span>
                <select
                  value={employee.availability}
                  onChange={(e) =>
                    updateEmployee(employee.id, {
                      availability: e.target.value as typeof employee.availability,
                    })
                  }
                  aria-label="Availability"
                  className="bg-[#14171B] border border-[#2A313D] rounded-lg px-2 py-0.5 text-xs font-semibold text-[#34D399]"
                >
                  <option value="Active">Active</option>
                  <option value="In Focus">In Focus</option>
                  <option value="On Leave">On Leave</option>
                </select>
              </span>
            </div>
          </div>

          <div className="border border-[#232933] bg-[#181C22] rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-sm font-bold text-[#F3F5F7]">
                Role, Workload &amp; Permissions
              </h3>
              {!editingRole && (
                <button
                  type="button"
                  onClick={startEdit}
                  className="text-xs font-semibold text-[#34D399] hover:text-[#6EE7B7]"
                >
                  Edit Role &amp; Hours
                </button>
              )}
            </div>

            {editingRole ? (
              <form onSubmit={saveEdit} className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-[#9CA3AF] mb-1">
                    Job Role Title
                  </label>
                  <input
                    type="text"
                    value={roleDraft}
                    onChange={(e) => setRoleDraft(e.target.value)}
                    className="w-full bg-[#14171B] border border-[#2A313D] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-[#9CA3AF] mb-1">
                    Department
                  </label>
                  <select
                    value={deptDraft}
                    onChange={(e) => setDeptDraft(e.target.value as Department)}
                    className="w-full bg-[#14171B] border border-[#2A313D] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
                  >
                    <option value="Product">Product</option>
                    <option value="Engineering">Engineering</option>
                    <option value="Design">Design</option>
                    <option value="Marketing">Marketing</option>
                    <option value="Quality Assurance">Quality Assurance</option>
                    <option value="Operations">Operations</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-[#9CA3AF] mb-1">
                    Access Level
                  </label>
                  <select
                    value={accessDraft}
                    onChange={(e) => setAccessDraft(e.target.value as AccessLevel)}
                    className="w-full bg-[#14171B] border border-[#2A313D] rounded-xl px-3 py-2 text-xs text-[#F3F5F7]"
                  >
                    <option value="Admin">Admin</option>
                    <option value="Manager">Manager</option>
                    <option value="Member">Member</option>
                    <option value="Viewer">Viewer</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-[#9CA3AF] mb-1">
                    Allocated Weekly Hours (/{employee.weeklyCapacityHours}h)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={60}
                    value={allocDraft}
                    onChange={(e) => setAllocDraft(Number(e.target.value))}
                    className="w-full bg-[#14171B] border border-[#2A313D] rounded-xl px-3 py-2 text-xs font-mono text-[#F3F5F7]"
                  />
                </div>
                <div className="sm:col-span-2 flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setEditingRole(false)}
                    className="px-3 py-1.5 rounded-xl text-xs font-medium text-[#9CA3AF] hover:bg-[#232933]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-3.5 py-1.5 rounded-xl text-xs font-bold text-[#051B0E] bg-[#00D26A] inline-flex items-center gap-1"
                  >
                    <Save className="w-3.5 h-3.5" />
                    Save Role
                  </button>
                </div>
              </form>
            ) : (
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-[#9CA3AF]">Weekly Capacity Allocation</span>
                  <span className="font-mono font-semibold text-[#F3F5F7] tabular-nums">
                    {employee.allocatedHours} / {employee.weeklyCapacityHours}h ({capacityPct}%)
                  </span>
                </div>
                <div className="w-full h-2 bg-[#111418] rounded-full overflow-hidden mb-4">
                  <div
                    className="h-full rounded-full bg-[#00D26A]"
                    style={{ width: `${capacityPct}%` }}
                  />
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {PERMISSION_KEYS.map((perm) => {
                const enabled = employee.permissions.includes(perm);
                return (
                  <button
                    key={perm}
                    type="button"
                    onClick={() => togglePerm(perm)}
                    className={`flex items-center justify-between gap-2 px-3 py-2 rounded-xl border text-left text-xs transition-colors ${
                      enabled
                        ? 'bg-[#00D26A]/10 border-[#00D26A]/30 text-[#34D399]'
                        : 'bg-[#14171B] border-[#252B35] text-[#9CA3AF]'
                    }`}
                  >
                    <span className="font-medium truncate">{PERMISSION_LABELS[perm].label}</span>
                    <span
                      className={`w-4 h-4 rounded inline-flex items-center justify-center shrink-0 ${
                        enabled ? 'bg-[#00D26A] text-[#051B0E]' : 'border border-[#374151]'
                      }`}
                    >
                      {enabled && <Check className="w-3 h-3 stroke-[2.6]" />}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <h3 className="font-display text-sm font-bold text-[#F3F5F7] mb-2">
              Active Projects ({empProjects.length})
            </h3>
            <div className="flex flex-wrap gap-2">
              {empProjects.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    setSelectedEmployeeId(null);
                    setSelectedProjectId(p.id);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-[#181C22] border border-[#252B35] hover:border-[#00D26A]/60 text-xs font-semibold text-[#F3F5F7]"
                >
                  {p.name}
                  {p.leadId === employee.id ? ' · Lead' : ''}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2.5">
              <h3 className="font-display text-sm font-bold text-[#F3F5F7]">
                Assigned Tasks ({empTasks.length})
              </h3>
              <button
                type="button"
                onClick={() => onOpenNewTaskForEmployee(employee.id)}
                className="text-xs font-semibold text-[#34D399] hover:text-[#6EE7B7] inline-flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                Assign Task
              </button>
            </div>

            <div className="divide-y divide-[#1F242C] border border-[#232933] bg-[#181C22] rounded-2xl overflow-hidden">
              {empTasks.length === 0 ? (
                <div className="p-4 text-xs text-[#6B7280] text-center">
                  No tasks currently assigned to {employee.name}.
                </div>
              ) : (
                empTasks.map((t) => {
                  const proj = projects.find((p) => p.id === t.projectId);
                  return (
                    <div
                      key={t.id}
                      className="p-3 flex items-center justify-between gap-3 hover:bg-[#1E232B]"
                    >
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedEmployeeId(null);
                          setSelectedTaskId(t.id);
                        }}
                        className="min-w-0 flex-1 text-left"
                      >
                        <div className="text-xs font-semibold text-[#F3F5F7] truncate">
                          {t.title}
                        </div>
                        <div className="text-[11px] text-[#9CA3AF] mt-0.5">
                          <span className="font-mono text-[#34D399]">{t.code}</span> · {proj?.name}{' '}
                          · Due {t.dueDate}
                        </div>
                      </button>

                      <select
                        value={t.status}
                        onChange={(e) => moveTaskStatus(t.id, e.target.value as TaskStatus)}
                        aria-label={`Status for ${t.title}`}
                        className="bg-[#14171B] border border-[#2A313D] rounded-lg px-2 py-1 text-[11px] font-medium text-[#F3F5F7]"
                      >
                        <option value="todo">To Do</option>
                        <option value="in_progress">In Progress</option>
                        <option value="in_review">In Review</option>
                        <option value="completed">Completed</option>
                      </select>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
