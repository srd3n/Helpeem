import React, { useState } from 'react';
import { CheckSquare, Plus, Square, Trash2, X } from 'lucide-react';
import { useCompany } from '../../store/CompanyContext';
import { TaskPriority, TaskStatus } from '../../types';

export const TaskDetailDrawer: React.FC = () => {
  const {
    tasks,
    projects,
    employees,
    selectedTaskId,
    setSelectedTaskId,
    updateTask,
    moveTaskStatus,
    toggleSubtask,
    deleteTask,
  } = useCompany();

  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');

  const task = tasks.find((t) => t.id === selectedTaskId);
  if (!task) return null;

  const doneSubs = task.subtasks.filter((s) => s.done).length;

  const handleAddSubtask = (e: React.FormEvent) => {
    e.preventDefault();
    const title = newSubtaskTitle.trim();
    if (!title) return;
    updateTask(task.id, {
      subtasks: [...task.subtasks, { id: `st-${Date.now()}`, title, done: false }],
    });
    setNewSubtaskTitle('');
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div
        className="fixed inset-0 bg-black/65 backdrop-blur-[1px]"
        onClick={() => setSelectedTaskId(null)}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-label={`${task.code} details`}
        className="relative z-10 w-full max-w-lg bg-[#14171B] h-full shadow-2xl border-l border-[#232933] flex flex-col text-[#F3F5F7]"
      >
        <div className="px-6 py-5 border-b border-[#232933] flex items-start justify-between gap-4">
          <div className="min-w-0">
            <span className="font-mono text-xs font-semibold text-[#34D399]">{task.code}</span>
            <h2 className="font-display text-lg font-bold text-[#F3F5F7] mt-0.5 leading-snug">
              {task.title}
            </h2>
          </div>

          <button
            type="button"
            onClick={() => setSelectedTaskId(null)}
            className="p-2 rounded-xl text-[#9CA3AF] hover:bg-[#1F242C] hover:text-white"
            aria-label="Close task details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div>
            <label className="block text-[11px] font-semibold text-[#9CA3AF] mb-1">
              Description
            </label>
            <textarea
              value={task.description}
              onChange={(e) => updateTask(task.id, { description: e.target.value })}
              rows={3}
              className="w-full bg-[#181C22] border border-[#252B35] rounded-xl p-3 text-xs text-[#F3F5F7] leading-relaxed focus:outline-none focus:border-[#00D26A]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-[#9CA3AF] mb-1">
                Workflow Stage
              </label>
              <select
                value={task.status}
                onChange={(e) => moveTaskStatus(task.id, e.target.value as TaskStatus)}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs font-semibold text-[#F3F5F7]"
              >
                <option value="todo">To Do</option>
                <option value="in_progress">In Progress</option>
                <option value="in_review">In Review</option>
                <option value="completed">Completed</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#9CA3AF] mb-1">
                Priority
              </label>
              <select
                value={task.priority}
                onChange={(e) => updateTask(task.id, { priority: e.target.value as TaskPriority })}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs font-semibold text-[#F3F5F7]"
              >
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Urgent">Urgent</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#9CA3AF] mb-1">
                Project
              </label>
              <select
                value={task.projectId}
                onChange={(e) => updateTask(task.id, { projectId: e.target.value })}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs font-medium text-[#F3F5F7]"
              >
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#9CA3AF] mb-1">
                Assignee
              </label>
              <select
                value={task.assigneeId}
                onChange={(e) => updateTask(task.id, { assigneeId: e.target.value })}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs font-medium text-[#F3F5F7]"
              >
                {employees.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} ({e.roleTitle})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#9CA3AF] mb-1">
                Due Date
              </label>
              <input
                type="date"
                value={task.dueDate}
                onChange={(e) => updateTask(task.id, { dueDate: e.target.value })}
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs font-mono text-[#F3F5F7]"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#9CA3AF] mb-1">
                Logged Hours (Est: {task.estimatedHours}h)
              </label>
              <input
                type="number"
                min={0}
                max={200}
                value={task.loggedHours}
                onChange={(e) =>
                  updateTask(task.id, { loggedHours: Math.max(0, Number(e.target.value) || 0) })
                }
                className="w-full bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs font-mono text-[#F3F5F7]"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2.5">
              <h3 className="font-display text-sm font-bold text-[#F3F5F7]">
                Subtasks Checklist ({doneSubs}/{task.subtasks.length})
              </h3>
            </div>

            <div className="space-y-2 mb-3">
              {task.subtasks.map((st) => (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => toggleSubtask(task.id, st.id)}
                  className="w-full flex items-center gap-2.5 p-2.5 rounded-xl bg-[#181C22] border border-[#252B35] hover:border-[#00D26A]/40 text-left transition-colors"
                >
                  {st.done ? (
                    <CheckSquare className="w-4 h-4 text-[#00D26A] shrink-0" />
                  ) : (
                    <Square className="w-4 h-4 text-[#6B7280] shrink-0" />
                  )}
                  <span
                    className={`text-xs ${
                      st.done ? 'line-through text-[#6B7280]' : 'text-[#F3F5F7] font-medium'
                    }`}
                  >
                    {st.title}
                  </span>
                </button>
              ))}
            </div>

            <form onSubmit={handleAddSubtask} className="flex items-center gap-2">
              <input
                type="text"
                value={newSubtaskTitle}
                onChange={(e) => setNewSubtaskTitle(e.target.value)}
                placeholder="Add a subtask step..."
                className="flex-1 bg-[#181C22] border border-[#252B35] rounded-xl px-3 py-2 text-xs text-[#F3F5F7] placeholder:text-[#6B7280] focus:outline-none focus:border-[#00D26A]"
              />
              <button
                type="submit"
                className="px-3 py-2 rounded-xl text-xs font-semibold bg-[#00D26A]/15 text-[#34D399] hover:bg-[#00D26A]/25 inline-flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                Add
              </button>
            </form>
          </div>
        </div>

        <div className="px-6 py-4 border-t border-[#232933] flex items-center justify-between bg-[#111418]">
          <button
            type="button"
            onClick={() => deleteTask(task.id)}
            className="px-3 py-2 rounded-xl text-xs font-semibold text-[#FB7185] hover:bg-rose-500/10 inline-flex items-center gap-1.5"
          >
            <Trash2 className="w-4 h-4" />
            Delete Task
          </button>

          <button
            type="button"
            onClick={() => setSelectedTaskId(null)}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-[#00D26A] text-[#051B0E] hover:bg-[#10E077]"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
