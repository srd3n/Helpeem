import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bell,
  Check,
  ChevronDown,
  FolderKanban,
  ListTodo,
  Menu,
  Plus,
  RotateCcw,
  Search,
  UserCheck,
} from 'lucide-react';
import { useCompany } from '../store/CompanyContext';
import { Avatar } from './Avatar';

interface TopBarProps {
  onOpenMobileMenu: () => void;
  onOpenNewTask: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ onOpenMobileMenu, onOpenNewTask }) => {
  const {
    employees,
    projects,
    tasks,
    activeUser,
    setActiveUserId,
    setActiveSection,
    setSelectedProjectId,
    setSelectedEmployeeId,
    setSelectedTaskId,
    notifications,
    markAllNotificationsRead,
    markNotificationRead,
    resetDemoData,
  } = useCompany();

  const [query, setQuery] = useState('');
  const [searchFocused, setSearchFocused] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const searchInputRef = useRef<HTMLInputElement>(null);
  const searchBoxRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter((n) => !n.read).length;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
      if (e.key === 'Escape') {
        setSearchFocused(false);
        setNotifOpen(false);
        setProfileOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (searchBoxRef.current && !searchBoxRef.current.contains(e.target as Node)) {
        setSearchFocused(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setProfileOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return { projects: [], tasks: [], employees: [] };
    return {
      projects: projects
        .filter(
          (p) =>
            p.name.toLowerCase().includes(q) || p.clientOrDept.toLowerCase().includes(q)
        )
        .slice(0, 3),
      tasks: tasks
        .filter(
          (t) => t.title.toLowerCase().includes(q) || t.code.toLowerCase().includes(q)
        )
        .slice(0, 4),
      employees: employees
        .filter(
          (e) =>
            e.name.toLowerCase().includes(q) ||
            e.roleTitle.toLowerCase().includes(q) ||
            e.department.toLowerCase().includes(q)
        )
        .slice(0, 3),
    };
  }, [query, projects, tasks, employees]);

  const hasResults =
    results.projects.length > 0 || results.tasks.length > 0 || results.employees.length > 0;

  return (
    <header className="h-[68px] bg-[#101317] border-b border-[#1F242C] px-4 lg:px-7 flex items-center justify-between gap-4 shrink-0">
      {/* Left: Mobile drawer trigger + Global Search */}
      <div className="flex items-center gap-3 flex-1 min-w-0 max-w-xl">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          className="lg:hidden p-2 rounded-xl text-[#9CA3AF] hover:bg-[#191E25] hover:text-white shrink-0"
          aria-label="Open navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div ref={searchBoxRef} className="relative flex-1 min-w-0">
          <div className="flex items-center gap-2.5 bg-[#15191F] border border-[#232933] focus-within:border-[#00D26A]/70 focus-within:bg-[#181D24] rounded-xl px-3.5 py-2 transition-colors">
            <Search className="w-4 h-4 text-[#6B7280] shrink-0" />
            <input
              ref={searchInputRef}
              type="text"
              value={query}
              onFocus={() => setSearchFocused(true)}
              onChange={(e) => {
                setQuery(e.target.value);
                setSearchFocused(true);
              }}
              placeholder="Search projects, tasks, or people..."
              className="w-full bg-transparent text-sm text-[#F3F5F7] placeholder:text-[#6B7280] focus:outline-none"
            />
            <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[11px] font-mono text-[#9CA3AF] bg-[#1D222B] border border-[#2A313D] rounded-md shrink-0">
              ⌘K
            </kbd>
          </div>

          {searchFocused && query.trim().length > 0 && (
            <div className="absolute left-0 right-0 top-[calc(100%+8px)] bg-[#15191F] border border-[#262C36] rounded-2xl shadow-2xl z-40 p-2 max-h-[380px] overflow-y-auto">
              {!hasResults ? (
                <div className="py-6 px-4 text-center text-sm text-[#9CA3AF]">
                  No matching projects, tasks, or team members for &quot;{query}&quot;.
                </div>
              ) : (
                <div className="space-y-2">
                  {results.projects.length > 0 && (
                    <div>
                      <div className="px-3 py-1 text-[11px] font-semibold text-[#6B7280]">
                        Projects
                      </div>
                      {results.projects.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => {
                            setSelectedProjectId(p.id);
                            setActiveSection('projects');
                            setQuery('');
                            setSearchFocused(false);
                          }}
                          className="w-full flex items-center justify-between px-3 py-2 rounded-xl hover:bg-[#1D222B] text-left"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <FolderKanban className="w-4 h-4 text-[#00D26A] shrink-0" />
                            <span className="text-sm font-medium text-[#F3F5F7] truncate">
                              {p.name}
                            </span>
                          </div>
                          <span className="text-xs text-[#9CA3AF] shrink-0">{p.clientOrDept}</span>
                        </button>
                      ))}
                    </div>
                  )}

                  {results.tasks.length > 0 && (
                    <div>
                      <div className="px-3 py-1 text-[11px] font-semibold text-[#6B7280]">
                        Tasks
                      </div>
                      {results.tasks.map((t) => (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => {
                            setSelectedTaskId(t.id);
                            setActiveSection('tasks');
                            setQuery('');
                            setSearchFocused(false);
                          }}
                          className="w-full flex items-center justify-between gap-3 px-3 py-2 rounded-xl hover:bg-[#1D222B] text-left"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <ListTodo className="w-4 h-4 text-[#D9A05B] shrink-0" />
                            <span className="text-xs font-mono text-[#9CA3AF] shrink-0">
                              {t.code}
                            </span>
                            <span className="text-sm font-medium text-[#F3F5F7] truncate">
                              {t.title}
                            </span>
                          </div>
                          <span className="text-xs text-[#9CA3AF] capitalize shrink-0">
                            {t.status.replace('_', ' ')}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}

                  {results.employees.length > 0 && (
                    <div>
                      <div className="px-3 py-1 text-[11px] font-semibold text-[#6B7280]">
                        Team &amp; Roles
                      </div>
                      {results.employees.map((emp) => (
                        <button
                          key={emp.id}
                          type="button"
                          onClick={() => {
                            setSelectedEmployeeId(emp.id);
                            setActiveSection('team');
                            setQuery('');
                            setSearchFocused(false);
                          }}
                          className="w-full flex items-center justify-between gap-3 px-3 py-2 rounded-xl hover:bg-[#1D222B] text-left"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <Avatar employee={emp} size="xs" />
                            <span className="text-sm font-medium text-[#F3F5F7] truncate">
                              {emp.name}
                            </span>
                          </div>
                          <span className="text-xs text-[#9CA3AF] shrink-0">{emp.roleTitle}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Right: Primary Action + Notifications + Profile */}
      <div className="flex items-center gap-2.5 sm:gap-3.5 shrink-0">
        <button
          type="button"
          onClick={onOpenNewTask}
          className="px-3.5 py-2 rounded-xl text-xs font-bold bg-[#00D26A] hover:bg-[#10E077] text-[#051B0E] inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
          <span>New Task</span>
        </button>

        {/* Notifications */}
        <div ref={notifRef} className="relative">
          <button
            type="button"
            onClick={() => setNotifOpen((v) => !v)}
            className="w-9 h-9 rounded-xl border border-[#232933] bg-[#15191F] hover:bg-[#1C2129] inline-flex items-center justify-center text-[#9CA3AF] hover:text-white relative transition-colors"
            aria-label="Notifications"
          >
            <Bell className="w-[18px] h-[18px]" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-[#00D26A] text-[#051B0E] text-[10px] font-bold flex items-center justify-center tabular-nums">
                {unreadCount}
              </span>
            )}
          </button>

          {notifOpen && (
            <div className="absolute right-0 top-[calc(100%+8px)] w-80 bg-[#15191F] border border-[#262C36] rounded-2xl shadow-2xl z-40 p-3">
              <div className="flex items-center justify-between px-1 pb-2.5 border-b border-[#232933]">
                <span className="text-sm font-semibold text-[#F3F5F7]">Notifications</span>
                {unreadCount > 0 && (
                  <button
                    type="button"
                    onClick={markAllNotificationsRead}
                    className="text-xs font-medium text-[#34D399] hover:text-[#6EE7B7] inline-flex items-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" />
                    Mark all read
                  </button>
                )}
              </div>
              <div className="divide-y divide-[#1F242C] max-h-72 overflow-y-auto">
                {notifications.map((n) => (
                  <button
                    key={n.id}
                    type="button"
                    onClick={() => {
                      markNotificationRead(n.id);
                      setActiveSection(n.targetSection);
                      setNotifOpen(false);
                    }}
                    className={`w-full text-left py-2.5 px-2 rounded-xl hover:bg-[#1D222B] transition-colors ${
                      n.read ? 'opacity-65' : ''
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-[#F3F5F7]">{n.title}</span>
                      <span className="text-[11px] text-[#6B7280] shrink-0">{n.time}</span>
                    </div>
                    <p className="text-xs text-[#9CA3AF] mt-0.5 leading-relaxed">{n.detail}</p>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Profile / Active User Switcher */}
        <div ref={profileRef} className="relative">
          <button
            type="button"
            onClick={() => setProfileOpen((v) => !v)}
            className="flex items-center gap-2.5 pl-1.5 pr-2 py-1 rounded-xl hover:bg-[#181D24] transition-colors text-left"
          >
            <Avatar employee={activeUser} size="sm" />
            <div className="hidden md:block leading-tight">
              <div className="text-[13px] font-semibold text-[#F3F5F7] whitespace-nowrap">
                {activeUser.name}
              </div>
              <div className="text-[11px] text-[#9CA3AF] whitespace-nowrap">
                {activeUser.roleTitle}
              </div>
            </div>
            <ChevronDown className="w-4 h-4 text-[#6B7280] hidden sm:block" />
          </button>

          {profileOpen && (
            <div className="absolute right-0 top-[calc(100%+8px)] w-64 bg-[#15191F] border border-[#262C36] rounded-2xl shadow-2xl z-40 p-2">
              <div className="px-3 py-2 border-b border-[#232933]">
                <div className="text-xs font-semibold text-[#F3F5F7]">{activeUser.name}</div>
                <div className="text-[11px] text-[#9CA3AF]">
                  {activeUser.roleTitle} · {activeUser.accessLevel}
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setSelectedEmployeeId(activeUser.id);
                  setActiveSection('team');
                  setProfileOpen(false);
                }}
                className="w-full flex items-center gap-2 px-3 py-2 mt-1 text-xs font-medium text-[#E5E7EB] hover:bg-[#1D222B] rounded-xl"
              >
                <UserCheck className="w-4 h-4 text-[#00D26A]" />
                View My Role &amp; Tasks
              </button>

              <div className="px-3 pt-2 pb-1 text-[11px] font-semibold text-[#6B7280]">
                Switch Perspective
              </div>
              <div className="max-h-40 overflow-y-auto space-y-0.5">
                {employees.slice(0, 6).map((emp) => (
                  <button
                    key={emp.id}
                    type="button"
                    onClick={() => {
                      setActiveUserId(emp.id);
                      setProfileOpen(false);
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl text-left text-xs ${
                      emp.id === activeUser.id
                        ? 'bg-[#00D26A]/15 text-[#34D399] font-semibold'
                        : 'text-[#9CA3AF] hover:bg-[#1D222B] hover:text-[#F3F5F7]'
                    }`}
                  >
                    <span className="flex items-center gap-2 truncate">
                      <Avatar employee={emp} size="xs" />
                      <span className="truncate">{emp.name}</span>
                    </span>
                    <span className="text-[10px] text-[#6B7280] shrink-0">{emp.accessLevel}</span>
                  </button>
                ))}
              </div>

              <div className="border-t border-[#232933] mt-1.5 pt-1.5">
                <button
                  type="button"
                  onClick={() => {
                    resetDemoData();
                    setProfileOpen(false);
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-[#9CA3AF] hover:text-[#FB7185] hover:bg-rose-500/10 rounded-xl transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Reset Workspace Data
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
