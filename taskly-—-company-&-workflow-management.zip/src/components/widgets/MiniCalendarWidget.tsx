import React, { useMemo, useState } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { useCompany } from '../../store/CompanyContext';

interface MiniCalendarWidgetProps {
  onViewAll: () => void;
}

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTH_NAMES = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export const MiniCalendarWidget: React.FC<MiniCalendarWidgetProps> = ({ onViewAll }) => {
  const { tasks, projects, setSelectedTaskId, setActiveSection } = useCompany();
  const [year, setYear] = useState(2026);
  const [month, setMonth] = useState(10);
  const [selectedDay, setSelectedDay] = useState('2026-11-20');

  const days = useMemo(() => {
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const prevMonthDays = new Date(year, month, 0).getDate();

    const grid: { dateStr: string; dayNum: number; inMonth: boolean }[] = [];

    for (let i = firstDay - 1; i >= 0; i--) {
      const d = prevMonthDays - i;
      const prevM = month === 0 ? 11 : month - 1;
      const prevY = month === 0 ? year - 1 : year;
      grid.push({
        dateStr: `${prevY}-${String(prevM + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`,
        dayNum: d,
        inMonth: false,
      });
    }

    for (let d = 1; d <= daysInMonth; d++) {
      grid.push({
        dateStr: `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`,
        dayNum: d,
        inMonth: true,
      });
    }

    const remaining = 42 - grid.length;
    for (let d = 1; d <= remaining; d++) {
      const nextM = month === 11 ? 0 : month + 1;
      const nextY = month === 11 ? year + 1 : year;
      grid.push({
        dateStr: `${nextY}-${String(nextM + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`,
        dayNum: d,
        inMonth: false,
      });
    }

    return grid.slice(0, 35);
  }, [year, month]);

  const eventsByDate = useMemo(() => {
    const map = new Map<string, number>();
    tasks.forEach((t) => {
      map.set(t.dueDate, (map.get(t.dueDate) ?? 0) + 1);
    });
    projects.forEach((p) => {
      p.milestones.forEach((m) => {
        map.set(m.dueDate, (map.get(m.dueDate) ?? 0) + 1);
      });
    });
    return map;
  }, [tasks, projects]);

  const dayTasks = useMemo(
    () => tasks.filter((t) => t.dueDate === selectedDay),
    [tasks, selectedDay]
  );

  const shiftMonth = (delta: number) => {
    const next = new Date(year, month + delta, 1);
    setYear(next.getFullYear());
    setMonth(next.getMonth());
  };

  return (
    <div className="bg-[#14171B] border border-[#232933] rounded-2xl p-5 flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display text-[16px] font-bold text-[#F3F5F7]">Calendar</h2>
          <button
            type="button"
            onClick={onViewAll}
            className="text-xs font-semibold text-[#34D399] hover:text-[#6EE7B7] inline-flex items-center gap-1"
          >
            View All
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center justify-between mb-3">
          <button
            type="button"
            onClick={() => shiftMonth(-1)}
            className="p-1.5 rounded-lg text-[#9CA3AF] hover:text-white hover:bg-[#1D222B]"
            aria-label="Previous month"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-sm font-semibold text-[#F3F5F7]">
            {MONTH_NAMES[month]} {year}
          </span>
          <button
            type="button"
            onClick={() => shiftMonth(1)}
            className="p-1.5 rounded-lg text-[#9CA3AF] hover:text-white hover:bg-[#1D222B]"
            aria-label="Next month"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-7 text-center mb-1.5">
          {WEEKDAYS.map((w) => (
            <span key={w} className="text-[11px] font-medium text-[#6B7280] py-1">
              {w}
            </span>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-y-1 text-center">
          {days.map((cell) => {
            const isSelected = cell.dateStr === selectedDay;
            const hasEvents = (eventsByDate.get(cell.dateStr) ?? 0) > 0;
            return (
              <button
                key={cell.dateStr}
                type="button"
                onClick={() => setSelectedDay(cell.dateStr)}
                className="flex flex-col items-center justify-center py-0.5 group"
              >
                <span
                  className={`w-7 h-7 rounded-full inline-flex items-center justify-center text-xs tabular-nums transition-colors ${
                    isSelected
                      ? 'bg-[#00D26A] text-[#051B0E] font-bold shadow-sm'
                      : cell.inMonth
                      ? 'text-[#E5E7EB] font-medium group-hover:bg-[#1D222B]'
                      : 'text-[#4B5563]'
                  }`}
                >
                  {cell.dayNum}
                </span>
                <span
                  className={`w-1 h-1 rounded-full mt-0.5 ${
                    hasEvents && !isSelected ? 'bg-[#00D26A]' : 'bg-transparent'
                  }`}
                />
              </button>
            );
          })}
        </div>
      </div>

      <div className="mt-3 pt-3 border-t border-[#1F242C]">
        <div className="flex items-center justify-between text-[11px] text-[#9CA3AF] mb-1.5">
          <span className="font-medium">Due on {selectedDay}</span>
          <span className="tabular-nums">
            {dayTasks.length} item{dayTasks.length === 1 ? '' : 's'}
          </span>
        </div>
        {dayTasks.length === 0 ? (
          <p className="text-xs text-[#6B7280]">No task deadlines scheduled for this day.</p>
        ) : (
          <div className="space-y-1">
            {dayTasks.slice(0, 2).map((task) => (
              <button
                key={task.id}
                type="button"
                onClick={() => {
                  setSelectedTaskId(task.id);
                  setActiveSection('tasks');
                }}
                className="w-full flex items-center justify-between gap-2 text-left text-xs px-2 py-1 rounded-lg hover:bg-[#1B2028] transition-colors"
              >
                <span className="truncate font-medium text-[#F3F5F7]">{task.title}</span>
                <span className="font-mono text-[10px] text-[#34D399] shrink-0">{task.code}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
