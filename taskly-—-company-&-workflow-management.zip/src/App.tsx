/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { EmployeeDetailDrawer } from './components/drawers/EmployeeDetailDrawer';
import { ProjectDetailDrawer } from './components/drawers/ProjectDetailDrawer';
import { TaskDetailDrawer } from './components/drawers/TaskDetailDrawer';
import { AddEmployeeModal, NewProjectModal, NewTaskModal } from './components/modals/CreateModals';
import { CalendarView } from './components/views/CalendarView';
import { DashboardView } from './components/views/DashboardView';
import { KanbanView } from './components/views/KanbanView';
import { ProjectsView } from './components/views/ProjectsView';
import { ReportsView } from './components/views/ReportsView';
import { TasksView } from './components/views/TasksView';
import { TeamRolesView } from './components/views/TeamRolesView';
import { CompanyProvider, useCompany } from './store/CompanyContext';

const WorkspaceShell: React.FC = () => {
  const { activeSection } = useCompany();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [newProjectOpen, setNewProjectOpen] = useState(false);
  const [addEmployeeOpen, setAddEmployeeOpen] = useState(false);
  const [newTaskConfig, setNewTaskConfig] = useState<{
    open: boolean;
    projectId?: string;
    assigneeId?: string;
    dueDate?: string;
  }>({ open: false });

  const openNewTask = (opts?: { projectId?: string; assigneeId?: string; dueDate?: string }) => {
    setNewTaskConfig({
      open: true,
      projectId: opts?.projectId,
      assigneeId: opts?.assigneeId,
      dueDate: opts?.dueDate,
    });
  };

  return (
    <div className="min-h-screen flex bg-[#0B0D10] text-[#F3F5F7]">
      <Sidebar
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        onOpenNewProject={() => setNewProjectOpen(true)}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <TopBar
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onOpenNewTask={() => openNewTask()}
        />

        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 max-w-[1440px] w-full mx-auto">
          {activeSection === 'dashboard' && (
            <DashboardView onOpenAddEmployee={() => setAddEmployeeOpen(true)} />
          )}
          {activeSection === 'projects' && (
            <ProjectsView onOpenNewProject={() => setNewProjectOpen(true)} />
          )}
          {activeSection === 'tasks' && <TasksView onOpenNewTask={() => openNewTask()} />}
          {activeSection === 'kanban' && <KanbanView onOpenNewTask={() => openNewTask()} />}
          {activeSection === 'team' && (
            <TeamRolesView onOpenAddEmployee={() => setAddEmployeeOpen(true)} />
          )}
          {activeSection === 'calendar' && (
            <CalendarView onOpenNewTask={(dueDate) => openNewTask({ dueDate })} />
          )}
          {activeSection === 'reports' && <ReportsView />}
        </main>
      </div>

      {/* Interactive Slide-Over Drawers */}
      <ProjectDetailDrawer
        onOpenNewTaskForProject={(projectId) => openNewTask({ projectId })}
      />
      <EmployeeDetailDrawer
        onOpenNewTaskForEmployee={(assigneeId) => openNewTask({ assigneeId })}
      />
      <TaskDetailDrawer />

      {/* Creation Modals */}
      <NewProjectModal open={newProjectOpen} onClose={() => setNewProjectOpen(false)} />
      <NewTaskModal
        open={newTaskConfig.open}
        onClose={() => setNewTaskConfig({ open: false })}
        defaultProjectId={newTaskConfig.projectId}
        defaultAssigneeId={newTaskConfig.assigneeId}
        defaultDueDate={newTaskConfig.dueDate}
      />
      <AddEmployeeModal open={addEmployeeOpen} onClose={() => setAddEmployeeOpen(false)} />
    </div>
  );
};

export default function App() {
  return (
    <CompanyProvider>
      <WorkspaceShell />
    </CompanyProvider>
  );
}
