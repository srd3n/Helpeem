export type NavSection =
  | 'dashboard'
  | 'projects'
  | 'tasks'
  | 'kanban'
  | 'team'
  | 'calendar'
  | 'reports';

export type Timeframe = 'week' | 'month' | 'quarter';

export type AccessLevel = 'Admin' | 'Manager' | 'Member' | 'Viewer';

export type Department =
  | 'Product'
  | 'Engineering'
  | 'Design'
  | 'Marketing'
  | 'Quality Assurance'
  | 'Operations';

export type PermissionKey =
  | 'manage_projects'
  | 'assign_tasks'
  | 'manage_roles'
  | 'view_reports'
  | 'approve_deliverables'
  | 'manage_budgets';

export interface Employee {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  avatarUrl?: string;
  initials: string;
  department: Department;
  roleTitle: string;
  accessLevel: AccessLevel;
  permissions: PermissionKey[];
  weeklyCapacityHours: number;
  allocatedHours: number;
  availability: 'Active' | 'In Focus' | 'On Leave';
  skills: string[];
  joinedDate: string;
  bio: string;
}

export type ProjectHealth = 'On Track' | 'At Risk' | 'Delayed';
export type ProjectStatus = 'Active' | 'Planning' | 'Completed';

export interface ProjectMilestone {
  id: string;
  title: string;
  dueDate: string;
  completed: boolean;
}

export interface Project {
  id: string;
  name: string;
  clientOrDept: string;
  description: string;
  leadId: string;
  memberIds: string[];
  health: ProjectHealth;
  status: ProjectStatus;
  manualProgress?: number;
  startDate: string;
  dueDate: string;
  budget: number;
  spent: number;
  iconKey: 'globe' | 'smartphone' | 'layers' | 'megaphone' | 'cloud' | 'sparkles';
  accentColor: string;
  milestones: ProjectMilestone[];
}

export type TaskStatus = 'todo' | 'in_progress' | 'in_review' | 'completed';
export type TaskPriority = 'Low' | 'Medium' | 'High' | 'Urgent';

export interface Subtask {
  id: string;
  title: string;
  done: boolean;
}

export interface Task {
  id: string;
  code: string;
  title: string;
  description: string;
  projectId: string;
  assigneeId: string;
  status: TaskStatus;
  priority: TaskPriority;
  dueDate: string;
  estimatedHours: number;
  loggedHours: number;
  subtasks: Subtask[];
  createdAt: string;
  updatedAt: string;
}

export interface ActivityItem {
  id: string;
  actorId: string;
  action: string;
  target: string;
  type: 'completed' | 'comment' | 'moved' | 'file' | 'project' | 'role';
  timestamp: string;
}

export interface TeamNote {
  id: string;
  authorId: string;
  message: string;
  timestamp: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  detail: string;
  time: string;
  read: boolean;
  targetSection: NavSection;
}

export interface AnalyticsPoint {
  label: string;
  completed: number;
  created: number;
}
