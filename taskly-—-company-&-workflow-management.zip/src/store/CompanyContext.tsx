import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import {
  INITIAL_ACTIVITIES,
  INITIAL_EMPLOYEES,
  INITIAL_NOTIFICATIONS,
  INITIAL_PROJECTS,
  INITIAL_TASKS,
  INITIAL_TEAM_NOTES,
} from '../data/initialData';
import {
  ActivityItem,
  Employee,
  NavSection,
  NotificationItem,
  Project,
  Task,
  TaskStatus,
  TeamNote,
} from '../types';

interface CompanyState {
  employees: Employee[];
  projects: Project[];
  tasks: Task[];
  activities: ActivityItem[];
  teamNotes: TeamNote[];
  notifications: NotificationItem[];
  activeUserId: string;
}

interface CompanyContextValue extends CompanyState {
  activeSection: NavSection;
  setActiveSection: (section: NavSection) => void;
  activeUser: Employee;
  setActiveUserId: (id: string) => void;
  selectedProjectId: string | null;
  setSelectedProjectId: (id: string | null) => void;
  selectedEmployeeId: string | null;
  setSelectedEmployeeId: (id: string | null) => void;
  selectedTaskId: string | null;
  setSelectedTaskId: (id: string | null) => void;
  getProjectProgress: (project: Project) => number;
  addProject: (project: Omit<Project, 'id'>) => Project;
  updateProject: (id: string, patch: Partial<Project>) => void;
  toggleMilestone: (projectId: string, milestoneId: string) => void;
  addTask: (task: Omit<Task, 'id' | 'code' | 'createdAt' | 'updatedAt'>) => Task;
  updateTask: (id: string, patch: Partial<Task>) => void;
  moveTaskStatus: (id: string, status: TaskStatus) => void;
  toggleSubtask: (taskId: string, subtaskId: string) => void;
  deleteTask: (id: string) => void;
  addEmployee: (emp: Omit<Employee, 'id'>) => Employee;
  updateEmployee: (id: string, patch: Partial<Employee>) => void;
  postTeamNote: (message: string) => void;
  markAllNotificationsRead: () => void;
  markNotificationRead: (id: string) => void;
  resetDemoData: () => void;
}

const STORAGE_KEY = 'fillupro_company_workspace_v1';

const defaultState: CompanyState = {
  employees: INITIAL_EMPLOYEES,
  projects: INITIAL_PROJECTS,
  tasks: INITIAL_TASKS,
  activities: INITIAL_ACTIVITIES,
  teamNotes: INITIAL_TEAM_NOTES,
  notifications: INITIAL_NOTIFICATIONS,
  activeUserId: 'emp-sarah',
};

const CompanyContext = createContext<CompanyContextValue | null>(null);

export const CompanyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<CompanyState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as Partial<CompanyState>;
        if (parsed.employees && parsed.projects && parsed.tasks) {
          return {
            employees: parsed.employees,
            projects: parsed.projects,
            tasks: parsed.tasks,
            activities: parsed.activities ?? INITIAL_ACTIVITIES,
            teamNotes: parsed.teamNotes ?? INITIAL_TEAM_NOTES,
            notifications: parsed.notifications ?? INITIAL_NOTIFICATIONS,
            activeUserId: parsed.activeUserId ?? 'emp-sarah',
          };
        }
      }
    } catch {
      // Ignore storage parse failure and use defaults
    }
    return defaultState;
  });

  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Ignore quota errors
    }
  }, [state]);

  const activeUser = useMemo(
    () => state.employees.find((e) => e.id === state.activeUserId) ?? state.employees[0],
    [state.employees, state.activeUserId]
  );

  const pushActivity = (
    prev: CompanyState,
    actorId: string,
    action: string,
    target: string,
    type: ActivityItem['type']
  ): ActivityItem[] => {
    const entry: ActivityItem = {
      id: `act-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      actorId,
      action,
      target,
      type,
      timestamp: 'Just now',
    };
    return [entry, ...prev.activities].slice(0, 20);
  };

  const getProjectProgress = (project: Project): number => {
    if (typeof project.manualProgress === 'number') {
      return project.manualProgress;
    }
    const projectTasks = state.tasks.filter((t) => t.projectId === project.id);
    if (projectTasks.length === 0) return 0;
    const weights: Record<TaskStatus, number> = {
      todo: 0,
      in_progress: 0.45,
      in_review: 0.8,
      completed: 1,
    };
    const sum = projectTasks.reduce((acc, task) => acc + weights[task.status], 0);
    return Math.round((sum / projectTasks.length) * 100);
  };

  const addProject = (projectInput: Omit<Project, 'id'>): Project => {
    const newProject: Project = {
      ...projectInput,
      id: `proj-${Date.now()}`,
    };
    setState((prev) => ({
      ...prev,
      projects: [newProject, ...prev.projects],
      activities: pushActivity(prev, prev.activeUserId, 'created project', newProject.name, 'project'),
    }));
    return newProject;
  };

  const updateProject = (id: string, patch: Partial<Project>) => {
    setState((prev) => {
      const existing = prev.projects.find((p) => p.id === id);
      const nextProjects = prev.projects.map((p) => (p.id === id ? { ...p, ...patch } : p));
      return {
        ...prev,
        projects: nextProjects,
        activities: existing
          ? pushActivity(prev, prev.activeUserId, 'updated project', existing.name, 'project')
          : prev.activities,
      };
    });
  };

  const toggleMilestone = (projectId: string, milestoneId: string) => {
    setState((prev) => {
      const targetProj = prev.projects.find((p) => p.id === projectId);
      const targetMs = targetProj?.milestones.find((m) => m.id === milestoneId);
      const nextProjects = prev.projects.map((p) => {
        if (p.id !== projectId) return p;
        return {
          ...p,
          milestones: p.milestones.map((m) =>
            m.id === milestoneId ? { ...m, completed: !m.completed } : m
          ),
        };
      });
      return {
        ...prev,
        projects: nextProjects,
        activities:
          targetProj && targetMs
            ? pushActivity(
                prev,
                prev.activeUserId,
                targetMs.completed ? 'reopened milestone in' : 'completed milestone in',
                targetProj.name,
                'project'
              )
            : prev.activities,
      };
    });
  };

  const addTask = (taskInput: Omit<Task, 'id' | 'code' | 'createdAt' | 'updatedAt'>): Task => {
    const today = '2026-11-20';
    const nextNumber = state.tasks.length + 101;
    const projPrefix =
      state.projects
        .find((p) => p.id === taskInput.projectId)
        ?.name.replace(/[^A-Za-z]/g, '')
        .slice(0, 3)
        .toUpperCase() || 'TSK';
    const newTask: Task = {
      ...taskInput,
      id: `task-${Date.now()}`,
      code: `${projPrefix}-${nextNumber}`,
      createdAt: today,
      updatedAt: today,
    };
    setState((prev) => {
      const projName =
        prev.projects.find((p) => p.id === newTask.projectId)?.name ?? 'Company Workspace';
      return {
        ...prev,
        tasks: [newTask, ...prev.tasks],
        activities: pushActivity(
          prev,
          prev.activeUserId,
          `created ${newTask.code} in`,
          projName,
          'moved'
        ),
      };
    });
    return newTask;
  };

  const updateTask = (id: string, patch: Partial<Task>) => {
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) =>
        t.id === id ? { ...t, ...patch, updatedAt: '2026-11-20' } : t
      ),
    }));
  };

  const moveTaskStatus = (id: string, status: TaskStatus) => {
    setState((prev) => {
      const task = prev.tasks.find((t) => t.id === id);
      if (!task || task.status === status) return prev;
      const proj = prev.projects.find((p) => p.id === task.projectId);
      const statusLabelMap: Record<TaskStatus, string> = {
        todo: 'To Do',
        in_progress: 'In Progress',
        in_review: 'In Review',
        completed: 'Completed',
      };
      const nextTasks = prev.tasks.map((t) =>
        t.id === id ? { ...t, status, updatedAt: '2026-11-20' } : t
      );
      return {
        ...prev,
        tasks: nextTasks,
        activities: pushActivity(
          prev,
          task.assigneeId || prev.activeUserId,
          status === 'completed' ? 'completed a task in' : `moved ${task.code} to`,
          status === 'completed' ? proj?.name ?? task.title : statusLabelMap[status],
          status === 'completed' ? 'completed' : 'moved'
        ),
      };
    });
  };

  const toggleSubtask = (taskId: string, subtaskId: string) => {
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) => {
        if (t.id !== taskId) return t;
        return {
          ...t,
          subtasks: t.subtasks.map((s) => (s.id === subtaskId ? { ...s, done: !s.done } : s)),
          updatedAt: '2026-11-20',
        };
      }),
    }));
  };

  const deleteTask = (id: string) => {
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.filter((t) => t.id !== id),
    }));
    if (selectedTaskId === id) setSelectedTaskId(null);
  };

  const addEmployee = (empInput: Omit<Employee, 'id'>): Employee => {
    const newEmp: Employee = {
      ...empInput,
      id: `emp-${Date.now()}`,
    };
    setState((prev) => ({
      ...prev,
      employees: [...prev.employees, newEmp],
      activities: pushActivity(
        prev,
        prev.activeUserId,
        'onboarded team member',
        `${newEmp.name} (${newEmp.roleTitle})`,
        'role'
      ),
    }));
    return newEmp;
  };

  const updateEmployee = (id: string, patch: Partial<Employee>) => {
    setState((prev) => {
      const target = prev.employees.find((e) => e.id === id);
      const nextEmployees = prev.employees.map((e) => (e.id === id ? { ...e, ...patch } : e));
      return {
        ...prev,
        employees: nextEmployees,
        activities: target
          ? pushActivity(
              prev,
              prev.activeUserId,
              'updated role & details for',
              patch.name ?? target.name,
              'role'
            )
          : prev.activities,
      };
    });
  };

  const postTeamNote = (message: string) => {
    const trimmed = message.trim();
    if (!trimmed) return;
    setState((prev) => ({
      ...prev,
      teamNotes: [
        {
          id: `note-${Date.now()}`,
          authorId: prev.activeUserId,
          message: trimmed,
          timestamp: 'Just now',
        },
        ...prev.teamNotes,
      ],
      activities: pushActivity(prev, prev.activeUserId, 'posted a team update on', 'Team Collaboration', 'comment'),
    }));
  };

  const markAllNotificationsRead = () => {
    setState((prev) => ({
      ...prev,
      notifications: prev.notifications.map((n) => ({ ...n, read: true })),
    }));
  };

  const markNotificationRead = (id: string) => {
    setState((prev) => ({
      ...prev,
      notifications: prev.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)),
    }));
  };

  const resetDemoData = () => {
    localStorage.removeItem(STORAGE_KEY);
    setState(defaultState);
    setSelectedProjectId(null);
    setSelectedEmployeeId(null);
    setSelectedTaskId(null);
  };

  return (
    <CompanyContext.Provider
      value={{
        ...state,
        activeSection,
        setActiveSection,
        activeUser,
        setActiveUserId: (id) => setState((prev) => ({ ...prev, activeUserId: id })),
        selectedProjectId,
        setSelectedProjectId,
        selectedEmployeeId,
        setSelectedEmployeeId,
        selectedTaskId,
        setSelectedTaskId,
        getProjectProgress,
        addProject,
        updateProject,
        toggleMilestone,
        addTask,
        updateTask,
        moveTaskStatus,
        toggleSubtask,
        deleteTask,
        addEmployee,
        updateEmployee,
        postTeamNote,
        markAllNotificationsRead,
        markNotificationRead,
        resetDemoData,
      }}
    >
      {children}
    </CompanyContext.Provider>
  );
};

export function useCompany() {
  const ctx = useContext(CompanyContext);
  if (!ctx) throw new Error('useCompany must be used inside CompanyProvider');
  return ctx;
}
